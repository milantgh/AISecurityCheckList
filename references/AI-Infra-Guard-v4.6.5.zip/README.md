<p align="center">
    <h1 align="center"><img vertical-align="middle" width="400px" src="img/logo-full-new.png" alt="A.I.G"/></h1>
</p>
<p align="center">
  <a href="https://tencent.github.io/AI-Infra-Guard/">📖 Documentation</a> &nbsp;|&nbsp;
  🌐 <a href="./readme/README_ZH.md">🇨🇳 中文</a> · <a href="./readme/README_JA.md">🇯🇵 日本語</a> · <a href="./readme/README_ES.md">🇪🇸 Español</a> · <a href="./readme/README_DE.md">🇩🇪 Deutsch</a> · <a href="./readme/README_FR.md">🇫🇷 Français</a> · <a href="./readme/README_KR.md">🇰🇷 한국어</a> · <a href="./readme/README_PT.md">🇧🇷 Português</a> · <a href="./readme/README_RU.md">🇷🇺 Русский</a>
</p>
<p align="center">
    <a href="https://github.com/tencent/AI-Infra-Guard/stargazers">
      <img src="https://img.shields.io/github/stars/tencent/AI-Infra-Guard?style=social" alt="GitHub stars">
    </a>
    <a href="https://github.com/Tencent/AI-Infra-Guard">
        <img alt="GitHub downloads" src="https://img.shields.io/github/downloads/Tencent/AI-Infra-Guard/total">
    </a>
    <a href="https://github.com/Tencent/AI-Infra-Guard">
        <img alt="docker pulls" src="https://img.shields.io/docker/pulls/zhuquelab/aig-server.svg?color=gold">
    </a>
    <a href="https://github.com/Tencent/AI-Infra-Guard">
        <img alt="Release" src="https://img.shields.io/github/v/release/Tencent/AI-Infra-Guard?color=green">
    </a>
    <a href="https://deepwiki.com/Tencent/AI-Infra-Guard">
       <img src="https://deepwiki.com/badge.svg" alt="Ask DeepWiki">
    </a>
</p>
<p align="center">
    <a href="https://clawhub.ai/aigsec/edgeone-clawscan" target="_blank">
       <img src="https://img.shields.io/badge/ClawHub-EdgeOne%20ClawScan-a870dc" alt="EdgeOne ClawScan">
    </a>
    <a href="https://clawhub.ai/aigsec/edgeone-skill-scanner" target="_blank">
       <img src="https://img.shields.io/badge/ClawHub-EdgeOne%20Skill%20Scanner-2ea44f" alt="EdgeOne Skill Scanner">
    </a>
    <a href="https://clawhub.ai/aigsec/aig-scanner" target="_blank">
       <img src="https://img.shields.io/badge/ClawHub-AIG%20Scanner-e6a817" alt="AIG Scanner">
    </a>
</p>
<p align="center">
    <a href="https://github.com/openclaw/clawscan" target="_blank">
       <img src="https://img.shields.io/badge/OpenClaw-Recommended-ff6b6b" alt="OpenClaw Recommended">
    </a>
</p>
<p align="center">
  <a href="https://trendshift.io/repositories/13637" target="_blank"><picture><source media="(prefers-color-scheme: dark)" srcset="https://trendshift.io/api/badge/repositories/13637"><source media="(prefers-color-scheme: light)" srcset="https://trendshift.io/api/badge/repositories/13637"><img src="https://trendshift.io/api/badge/repositories/13637" alt="Tencent%2FAI-Infra-Guard | Trendshift" width="250" height="55"/></picture></a>&nbsp;
  <a href="https://www.blackhat.com/eu-25/arsenal/schedule/index.html#aigai-infra-guard-48381" target="_blank"><img src="img/blackhat.png" alt="Tencent%2FAI-Infra-Guard | blackhat" width="175" height="55"/></a>&nbsp;
  <a href="https://github.com/deepseek-ai/awesome-deepseek-integration" target="_blank"><img src="img/awesome-deepseek.png" alt="Tencent%2FAI-Infra-Guard | awesome-deepseek-integration" width="273" height="55"/></a>
</p>

<br>

<p align="center">
    <h2 align="center">🚀 AI Red Teaming Platform by Tencent Zhuque Lab</h2>
</p>

<b>A.I.G (AI-Infra-Guard)</b> integrates capabilities such as ClawScan(OpenClaw Security Scan), Agent Scan，AI infra vulnerability scan, MCP Server & Agent Skills scan, and Jailbreak Evaluation, aiming to provide users with the most comprehensive, intelligent, and user-friendly solution for AI security risk self-examination.

<p>
  We are committed to making A.I.G(AI-Infra-Guard) the industry-leading AI red teaming platform. More stars help this project reach a wider audience, attracting more developers to contribute, which accelerates iteration and improvement. Your star is crucial to us!
</p>
<p align="center">
  <a href="https://github.com/Tencent/AI-Infra-Guard">
      <img src="https://img.shields.io/badge/⭐-Give%20us%20a%20Star-yellow?style=for-the-badge&logo=github" alt="Give us a Star">
  </a>
</p>

<br>

## 📋 User Feedback Survey

Help us improve A.I.G! Please take 3-5 minutes to fill out our [User Feedback Survey](https://doc.weixin.qq.com/forms/AJEAIQdfAAoAFkA0QbdAFwCNcKSO0BFLf). Users who provide high-quality feedback and leave a valid email address will receive an exclusive Tencent souvenir gift.

<br>

## 🚀 What's New

- **2026-09-17** · [v4.6.2](https://github.com/Tencent/AI-Infra-Guard/releases/tag/v4.6.2) — Vuln library expanded with 155 new CVE rules across 40+ AI components (LangFlow, n8n, PraisonAI, vLLM, llama-cpp, MLflow & more); Skill-Scan accuracy improvements (fewer evidence-free false positives, stall-free streaming); new agent loss-of-control benchmarks (FORGE-Bench, RogueHandoff-20).
- **2026-09-10** · [v4.6.1](https://github.com/Tencent/AI-Infra-Guard/releases/tag/v4.6.1) — API Checker: expanded model fingerprint coverage (Gemini 2.5/3.1, Gemma 2/3/4, GLM-5.3 & GLM-5.3-Flash); MCP-Scan reliability: flags empty/incomplete scans, preserves security findings during context compaction, surfaces underlying connection errors; corrected mislabeled CVE product names.
- **2026-08-26** · [v4.6.0](https://github.com/Tencent/AI-Infra-Guard/releases/tag/v4.6.0) — LLM API poisoning detection (multi-probe black-box audit for model substitution & backdoor risks); Agent-Scan v5.0.0 mutation engine refactor; vuln library expanded to 146 AI components & 2000+ CVE rules; MCP/Skill scan stability & compatibility fixes.
- **2026-08-17** · [v4.5.2](https://github.com/Tencent/AI-Infra-Guard/releases/tag/v4.5.2) — Skill-Scan: .pyc bytecode bypass detection + charset smuggling defense; MCP-Scan: RCE prevention via tool whitelisting in dynamic mode; new SkillJack research project; vuln library expanded to 2000+ CVE rules.
- **2026-07-30** · [v4.5.1](https://github.com/Tencent/AI-Infra-Guard/releases/tag/v4.5.1) — Jailbreak Evaluation: 4 multi-turn jailbreak attacks (Many-Shot, PAIR, GOAT, ActorAttack); Agent-Scan: 5 new OWASP skills + web-exfiltration detection (10 skills total); MCP-Scan: 4 new security rules

👉 [Earlier releases](./CHANGELOG.md) · 🛒 [AI Security Skill Market](https://matrix.tencent.com/skill-market/) · 🔍 [skill-scan CLI](https://github.com/Tencent/AI-Infra-Guard/tree/main/skill-scan) · 🔍 [mcp-scan CLI](https://github.com/Tencent/AI-Infra-Guard/tree/main/mcp-scan) · 🔍 [agent-scan CLI](https://github.com/Tencent/AI-Infra-Guard/tree/main/agent-scan) · 📊 [SkillTrustBench](https://matrix.tencent.com/skilltrustbench/)


## Table of Contents
- [🚀 Quick Start](#-quick-start)
- [✨ Features](#-features)
- [🖼️ Showcase](#-showcase)
- [📖 User Guide](#-user-guide)
- [🔧 API Documentation](#-api-documentation)
- [🏗️ Architecture Evolution](./docs/architecture_evolution.md)
- [📝 Contribution Guide](#-contribution-guide)
- [🛡️ About the Team](#️-about-the-team)
- [🙏 Acknowledgements](#-acknowledgements)
- [💬 Join the Community](#-join-the-community)
- [📖 Citation](#-citation)
- [📚 Research & Papers](#-research--papers)
- [⚖️ License & Attribution](#️-license--attribution)
<br><br>
## 🚀 Quick Start
### 🐳 Deploy A.I.G with Docker

| Docker | RAM | Disk Space |
|:-------|:----|:----------|
| 20.10 or higher | 4GB+ | 10GB+ |

```bash
# This method pulls pre-built images from Docker Hub for a faster start
git clone https://github.com/Tencent/AI-Infra-Guard.git
cd AI-Infra-Guard
# For Docker Compose V2+, replace 'docker-compose' with 'docker compose'
docker-compose -f docker-compose.images.yml up -d
```

Once the service is running, you can access the A.I.G web interface at:
`http://localhost:8088`
<br>

#### Use from OpenClaw

You can also call A.I.G directly from OpenClaw chat via the `aig-scanner` skill.

```bash
clawhub install aig-scanner
```

Then configure `AIG_BASE_URL` to point to your running A.I.G service.

For more details, see the [`aig-scanner` README](./skills/aig-scanner/README.md).

<details>
<summary><strong>More installation options</strong></summary>

### Other Installation Methods

**Method 2: One-Click Install Script （Recommended）**
```bash
# This method will automatically install Docker and launch A.I.G with one command
curl https://raw.githubusercontent.com/Tencent/AI-Infra-Guard/refs/heads/main/docker.sh | bash
```

**Method 3: Build and run from source**
```bash
git clone https://github.com/Tencent/AI-Infra-Guard.git
cd AI-Infra-Guard
# This method builds a Docker image from local source code and starts the service
# (For Docker Compose V2+, replace 'docker-compose' with 'docker compose')
docker-compose up -d
```

Note: The AI-Infra-Guard project is positioned as an AI red teaming platform for internal use by enterprises or individuals. It currently lacks an authentication mechanism and should not be deployed on public networks.

For more information, see: [https://tencent.github.io/AI-Infra-Guard/?menu=getting-started](https://tencent.github.io/AI-Infra-Guard/?menu=getting-started)

</details>

### ⚡ Install aig-skill-scan with a Single Command

Agent Skill security audit tool, easily integrated into enterprise CI/CD pipelines. Vulnerability classification aligns with [SkillTrustBench](https://matrix.tencent.com/skilltrustbench/) T01–T09 taxonomy. [Learn more →](https://github.com/Tencent/AI-Infra-Guard/tree/main/skill-scan)

```bash
pip install aig-skill-scan

# Set API key via environment variable
export LLM_API_KEY="your-api-key"

# Scan a local Skill project directory
aig-skill-scan --repo /path/to/your/skill \
           -m deepseek-v4-flash \
           --language en \
           -o result.json
```

### Model and API Relay Checker

The checker frontend is deployed separately. Docker deployment keeps the
checker APIs available at `GET /api/v1/relay/models` and
`POST /api/v1/relay/check/stream`; API documentation is available at
`http://127.0.0.1:8088/api-checker/docs`. To run the checker and unified CLI
from source:

```bash
python3 -m venv services/api_checker/.venv
services/api_checker/.venv/bin/pip install -r services/api_checker/requirements.txt
go build -o ai-infra-guard ./cmd/cli/main.go

export AIG_API_CHECKER_PYTHON="$PWD/services/api_checker/.venv/bin/python"
./ai-infra-guard api-checker list
./ai-infra-guard api-checker audit
```

See the [API Checker integration guide](docs/api-checker-integration.md) for
the Agent-embedded runtime architecture, HTTP API, configuration, and security boundaries.

### 🌟 Try the Online Pro Version
Experience the Pro version with advanced features and improved performance. The Pro version requires an [invitation code](https://wj.qq.com/s2/25099467/25vn/) and is prioritized for contributors who have submitted issues, pull requests, or discussions, or actively help grow the community. Visit: [https://aigsec.ai/](https://aigsec.ai/).
<br>
<br>

## ✨ Features

### 🔍 aig-skill-scan Performance & Coverage

Performance on [SkillTrustBench](https://matrix.tencent.com/skilltrustbench/) with different LLMs:

| # | Model | F1 | Precision | Recall | FPR |
|:--|:------|:---|:----------|:-------|:----|
| 1 | Claude Opus 4.6 | **0.9848** | 0.9725 | **0.9974** | 0.0663 |
| 2 | GLM 5.1 | 0.9836 | 0.9701 | **0.9974** | 0.0723 |
| 3 | Gemini 3.5 Flash | 0.9792 | **0.9947** | 0.9641 | **0.0120** |
| 4 | Kimi 2.6 | 0.9780 | 0.9895 | 0.9667 | 0.0241 |
| 5 | DeepSeek v4 Flash | 0.9740 | 0.9868 | 0.9615 | 0.0301 |

Covers 9 categories of Skill security risks (SkillTrustBench T01–T09):

| Layer | Risks |
|:------|:--------|
| A · Instruction & Memory | T01 Skill Instruction Hijacking, T02 Memory Poisoning |
| B · Code Execution | T03 Remote Payload Download & Execution, T04 Embedded Malicious Code |
| C · System Privilege | T05 Privilege Escalation & Unauthorized Access, T06 System Persistence |
| D · Toolchain & Dependencies | T07 Tool Hijacking & Spoofing, T08 Insecure Dependencies |
| E · Skill Code Quality | T09 Insecure Coding Practices |

For full leaderboard and details, visit [SkillTrustBench](https://matrix.tencent.com/skilltrustbench/).

### 🔬 Security Scanning & Evaluation

| Feature | More Info |
|:--------|:------------|
| **[ClawScan(OpenClaw&nbsp;Security&nbsp;Scan)](https://matrix.tencent.com/clawscan)** | Supports one-click evaluation of OpenClaw security risks. It detects insecure configurations, Skill risks, CVE vulnerabilities, and privacy leakage.  |
| **Agent&nbsp;Scan** | This is an independent, multi-agent automated scanning framework. It is designed to evaluate the security of AI agent workflows. It seamlessly supports agents running across various platforms, including Dify and Coze. |
| **MCP&nbsp;Server&nbsp;&&nbsp;Agent&nbsp;Skills&nbsp;scan** | It thoroughly detects 14 major categories of security risks. The detection applies to both MCP Servers and Agent Skills. It flexibly supports scanning from both source code and remote URLs. |
| **AI&nbsp;infra&nbsp;vulnerability&nbsp;scan** | This scanner precisely identifies over 100 AI framework components. It covers more than 2000 known CVE vulnerabilities. Supported frameworks include Ollama, ComfyUI, vLLM, n8n, Triton Inference Server and more. |
| **Jailbreak&nbsp;Evaluation** | It assesses prompt security risks using carefully curated datasets. The evaluation applies multiple attack methods to test robustness. It also provides detailed cross-model comparison capabilities. |
| **Model and API Relay Checker** | Model fingerprinting, Claude Signature verification, relay black-box auditing, PAMELA, and Ventor QTest. |

<details>
<summary><strong>💎 Additional Benefits</strong></summary>

- 🖥️ **Modern Web Interface**: User-friendly UI with one-click scanning and real-time progress tracking
- 🔌 **Complete API**: Full interface documentation and Swagger specifications for easy integration
- 🤖 **Agent-Ready**: Plug-and-play agent skills on ClawHub — [EdgeOne ClawScan](https://clawhub.ai/aigsec/edgeone-clawscan), [EdgeOne Skill Scanner](https://clawhub.ai/aigsec/edgeone-skill-scanner), and [AIG Scanner](https://clawhub.ai/aigsec/aig-scanner) — seamlessly embed security scanning into any AI agent workflow
- 🌐 **Multi-Language**: Chinese and English interfaces with localized documentation
- 🐳 **Cross-Platform**: Linux, macOS, and Windows support with Docker-based deployment
- 🆓 **Free & Open Source**: Completely free under the Apache 2.0 license
</details>

<br />


## 🖼️ Showcase

### A.I.G Main Interface
![A.I.G Main Page](img/aig.gif)

### Plugin Management
![Plugin Management](img/plugin-gif.gif)

<br />


## 🗺️ Quick Usage Guide

> After deployment, open `http://localhost:8088` in your browser.

### AI Infrastructure Vulnerability Scan

**What to enter as the target URL / IP?**

The target is the **network address of a running AI service** you want to scan - not a GitHub URL or source code path. A.I.G connects to the live service and fingerprints it for known CVE vulnerabilities.

| Scenario | Example target |
|:---------|:--------------|
| A locally running vLLM instance | `http://127.0.0.1:8000` |
| An Ollama server on your LAN | `http://192.168.1.100:11434` |
| A ComfyUI instance exposed internally | `http://10.0.0.5:8188` |
| Multiple hosts (one per line) | `192.168.1.0/24` (CIDR), `10.0.0.1-10.0.0.20` (range) |

**Step-by-step: Scan a local vLLM instance**

1. Start vLLM normally (e.g. `python -m vllm.entrypoints.api_server --model meta-llama/...`)
2. In the A.I.G web UI, click **"AI基础设施安全扫描 / AI Infra Scan"**
3. Enter `http://127.0.0.1:8000` (or the IP/port where vLLM is listening)
4. Click **Start Scan** - A.I.G will fingerprint the service and match it against 2000+ known CVEs
5. View the report: component version, matched vulnerabilities, severity, and remediation links

> 💡 **Tip**: To scan the *nightly* build of vLLM specifically, just run that nightly build and point A.I.G at its address. The scanner detects the version automatically.

### MCP Server & Agent Skills Scan

Enter either a **remote URL** (e.g. `https://github.com/user/mcp-server`) or **upload a local source archive** - no running instance required.

### Jailbreak Evaluation

Configure the target LLM's API endpoint (base URL + API key) in **Settings → Model Config**, then select a dataset and start the evaluation.

---

## 📖 User Guide

Visit our online documentation: [https://tencent.github.io/AI-Infra-Guard/](https://tencent.github.io/AI-Infra-Guard/)

For more detailed FAQs and troubleshooting guides, visit our [documentation](https://tencent.github.io/AI-Infra-Guard/?menu=faq).
<br />
<br>

## 🔧 API Documentation

A.I.G provides a comprehensive set of task creation APIs that support AI infra scan, MCP Server Scan, and Jailbreak Evaluation capabilities.

After the project is running, visit `http://localhost:8088/docs/index.html` to view the complete API documentation.

For detailed API usage instructions, parameter descriptions, and complete example code, please refer to the [Complete API Documentation](./api.md).
<br />
<br>

## 📝 Contribution Guide

The extensible plugin framework​​ serves as A.I.G's architectural cornerstone, inviting community innovation through Plugin and Feature contributions.​

### Plugin Contribution Rules
1.  **Fingerprint Rules**: Add new YAML fingerprint files to the `data/fingerprints/` directory.
2.  **Vulnerability Rules**: Add new vulnerability scan rules to the `data/vuln/` directory.
3.  **MCP Plugins**: Add new MCP security scan rules to the `data/mcp/` directory.
4.  **Jailbreak Evaluation Datasets**: Add new Jailbreak evaluation datasets to the `data/eval` directory.

Please refer to the existing rule formats, create new files, and submit them via a Pull Request.

### Other Ways to Contribute
- 🐛 [Report a Bug](https://github.com/Tencent/AI-Infra-Guard/issues)
- 💡 [Suggest a New Feature](https://github.com/Tencent/AI-Infra-Guard/issues)
- ⭐ [Improve Documentation](https://github.com/Tencent/AI-Infra-Guard/pulls)
<br />
<br />

## 🛡️ About the Team

This project is led and developed by **Tencent Zhuque Lab**, part of the Tencent Security Platform Department. Founded in 2019, [Tencent Zhuque Lab](https://matrix.tencent.com/) is a top-tier security research lab focused on real-world offensive and defensive research and frontier technology in the AI security space, covering large model security, AI agent security, AI-empowered security, and AI-generated content detection.

The team has helped major vendors such as **NVIDIA, Google, and Microsoft**, as well as open-source communities like **OpenClaw, Linux, and Hugging Face**, fix a large number of high-risk vulnerabilities, and has been publicly acknowledged by them.

We have released open-source AI security products including the AI Red Team Security Testing Platform <b>A.I.G (AI-Infra-Guard)</b> and the **Zhuque AI Detection Assistant**. Our research has been widely published at top international security and AI conferences such as **Black Hat, DEF CON, ICLR, CVPR, NeurIPS, and ACL**, and we have authored the book *"AI Security: Technology and Practice"*.

### 👥 Core Members & Contributions

| Role | Member | Contribution |
| --- | --- | --- |
| Head of Tencent Security Platform Department | **Yong Yang** | Initiated A.I.G and proposed automated assessment of AI agent loss-of-control risks, guiding the platform's expansion from AI infrastructure vulnerability scanning to agent execution risk, tool misuse, and permission-boundary evaluation. |
| Head of Tencent Zhuque Lab | **Xing Zheng** | Proposed the automated vulnerability-update and benchmark-alignment mechanism, helping AI Infra fingerprints, CVE/GHSA rules, and benchmarks iterate continuously. |
| Project Lead | **Nicky** | Frontier security research, product planning, technical-route decisions, internal and external collaboration, and communications. |
| Technical Lead | **Python** | Overall architecture design, core module development, and version iteration. |
| Core Contributor | **Zona** | Frontend interaction, product experience, community operations, and user-feedback loop. |
| Core Contributor | **Fyoung** | AI Infra vulnerability component fingerprint updates and Benchmark system construction. |
| Core Contributor | **Xiangfan** | Security capability development for Skill risks and agent loss-of-control scenarios. |
| Core Contributor | **Elwood** | Enhancing Agent security scanning capabilities and updating technical reports. |
| Core Contributor | **Robert** | LLM safety assessment and jailbreak-evaluation strategy operations. |
| Core Contributor | **Zoe** | LLM safety assessment, jailbreak evaluation, and model-integration module development. |
| Contributor | **Ronin** | Participated in AI agent security scanning development. |
| Contributor | **Rsin** | Participated in community operations and campaign communications. |

<br />

## 🙏 Acknowledgements

### 🎓 Academic Collaborations

We thank our academic partners for their research contributions and technical support.

#### <img src="img/北大未来网络重点实验室2.png" height="30" align="middle"/>
<table>
  <tr>
    <td align="center" width="90">
      <a href="#">
        <img src="https://avatars.githubusercontent.com/u/0?v=4" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="#">
        <sub><b>Prof.&nbsp;hui&nbsp;Li</b></sub>
      </a>
    </td>
    <td align="center" width="90">
      <a href="https://github.com/TheBinKing">
        <img src="https://avatars.githubusercontent.com/TheBinKing" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:1546697086@qq.com">
        <sub><b>Bin&nbsp;Wang</b></sub>
      </a>
    </td>
    <td align="center" width="90">
      <a href="https://github.com/KPGhat">
        <img src="https://avatars.githubusercontent.com/KPGhat" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:kpghat@gmail.com">
        <sub><b>Zexin&nbsp;Liu</b></sub>
      </a>
    </td>
    <td align="center" width="90">
      <a href="https://github.com/GioldDiorld">
        <img src="https://avatars.githubusercontent.com/GioldDiorld" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:g.diorld@gmail.com">
        <sub><b>Hao&nbsp;Yu</b></sub>
      </a>
    </td>
    <td align="center" width="90">
      <a href="https://github.com/Jarvisni">
        <img src="https://avatars.githubusercontent.com/Jarvisni" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:719001405@qq.com">
        <sub><b>Ao&nbsp;Yang</b></sub>
      </a>
    </td>
    <td align="center" width="90">
      <a href="https://github.com/Zhengxi7">
        <img src="https://avatars.githubusercontent.com/Zhengxi7" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:linzhengxi7@126.com">
        <sub><b>Zhengxi&nbsp;Lin</b></sub>
      </a>
    </td>
  </tr>
</table>

#### <img src="img/复旦大学2.png" height="30" align="middle" style="vertical-align: middle;"/>

<table>
  <tr>
    <td align="center" width="120">
      <a href="https://yangzhemin.github.io/">
        <img src="https://avatars.githubusercontent.com/yangzhemin" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:yangzhemin@fudan.edu.cn">
        <sub><b>Prof.&nbsp;Zhemin&nbsp;Yang</b></sub>
      </a>
    </td>
    <td align="center" width="100">
      <a href="https://github.com/kangwei-zhong">
        <img src="https://avatars.githubusercontent.com/kangwei-zhong" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:kwzhong23@m.fudan.edu.cn">
        <sub><b>Kangwei&nbsp;Zhong</b></sub>
      </a>
    </td>
    <td align="center" width="90">
      <a href="https://github.com/MoonBirdLin">
        <img src="https://avatars.githubusercontent.com/MoonBirdLin" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:linjp23@m.fudan.edu.cn">
        <sub><b>Jiapeng&nbsp;Lin</b></sub>
      </a>
    </td>
    <td align="center" width="90">
      <a href="https://vanilla-tiramisu.github.io/">
        <img src="https://avatars.githubusercontent.com/vanilla-tiramisu" width="70px;" style="border-radius: 50%;" alt=""/>
      </a>
      <br />
      <a href="mailto:csheng25@m.fudan.edu.cn">
        <sub><b>Cheng&nbsp;Sheng</b></sub>
      </a>
    </td>
  </tr>
</table>
<br>

### 👥 Gratitude to Contributing Developers
Thanks to all the developers who have contributed to the A.I.G project.
<br />
<table border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="33%"><img src="img/keen_lab_logo.svg" alt="Keen Lab" height="85%"></td>
    <td width="33%"><img src="img/wechat_security.png" alt="WeChat Security" height="85%"></td>
    <td width="33%"><img src="img/fit_sec_logo.png" alt="Fit Security" height="85%"></td>
  </tr>
</table>
<a href="https://github.com/Tencent/AI-Infra-Guard/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=Tencent/AI-Infra-Guard" />
</a>
<br>
<br>

### 🤝 Appreciation for Our Users

Thanks to the users from the following organizations and teams for using A.I.G and their valuable feedback.

<br>
<div align="center">
<img src="img/tencent.png" alt="Tencent" height="28px">
<img src="img/deepseek.png" alt="DeepSeek" height="38px">
<img src="img/antintl.svg" alt="Antintl" height="45px">
<img src="img/lenovo.png" alt="Lenovo" height="35px">
<img src="img/ICBC.jpg" alt="ICBC" height="40px">
<img src="img/vivo.png" alt="Vivo" height="30px">
<img src="img/oppo.png" alt="Oppo" height="30px">
<img src="img/haier.png" alt="Haier" height="30px">
<img src="img/abc.png" alt="Abc" height="40px">
<img src="img/JkOvmDOXpr.png" alt="招商银行" height="40px">
<img src="img/中国电信.png" alt="中国电信" height="40px">
<img src="img/bilibili.jpg" alt="Bilibili" height="38px">
<img src="img/qunar.png" alt="Qunar" height="35px">
<img src="img/蜜雪冰城.png" alt="蜜雪冰城" height="40px">
<img src="img/IDG.webp" alt="IDG" height="55px">
<img src="img/kingdee.png" alt="kingdee" height="40px">
<img src="img/unicom.png" alt="联通数科" height="40px">
<img src="img/changan.png" alt="长安汽车" height="40px">
<img src="img/tiane.png" alt="天鹅到家" height="35px">
</div>

<div align="center">
<img src="img/清华大学.jpg" alt="清华大学" height="40px">
<img src="img/北京大学.png" alt="北京大学" height="40px">
<img src="img/nanyang.png" alt="南洋理工大学" height="40px">
<img src="img/fudan.png" alt="复旦大学" height="40px">
<img src="img/浙江大学.png" alt="浙江大学" height="40px">
<img src="img/南京大学.png" alt="南京大学" height="40px">
<img src="img/wuhan.png" alt="武汉大学" height="40px">
<img src="img/An-NajahNationalUniversity.png" alt="An-Najah National University" height="40px">
<img src="img/西安交通大学.png" alt="西安交通大学" height="40px">
<img src="img/huazhong.png" alt="华中科技大学" height="45px">
<img src="img/南开大学.jpg" alt="南开大学" height="45px">
<img src="img/四川大学.png" alt="四川大学" height="40px">
<img src="img/Binus_University.svg" alt="Binus University" height="45px">
</div>

<br>
<br>

## 💬 Join the Community

### 🌐 Online Discussions
- **GitHub Discussions**: [Join our community discussions](https://github.com/Tencent/AI-Infra-Guard/discussions)
- **Issues & Bug Reports**: [Report issues or suggest features](https://github.com/Tencent/AI-Infra-Guard/issues)

### 📱 Discussion Community
<table>
  <thead>
  <tr>
    <th>WeChat Group</th>
    <th>Discord <a href="https://discord.gg/U9dnPnyadZ">[link]</a></th>
  </tr>
  </thead>
  <tbody>
  <tr>
    <td><img src="img/wechatgroup.png" alt="WeChat Group" width="200"></td>
    <td><img src="img/discord.png" alt="discord" width="200"></td>
  </tr>
  </tbody>
</table>

### 📧 Contact Us
For collaboration inquiries or feedback, please contact us at: [zhuque@tencent.com](mailto:zhuque@tencent.com)

### 🔗 Recommended Security Tools
If you are interested in code security, check out [A.S.E (AICGSecEval)](https://github.com/Tencent/AICGSecEval), the industry's first repository-level AI-generated code security evaluation framework open-sourced by the Tencent Wukong Code Security Team.




<br>
<br>

## 📖 Citation

If you use A.I.G in your research, please cite:

```bibtex
@misc{Tencent_AI-Infra-Guard_2025,
  author={{Tencent Zhuque Lab}},
  title={{AI-Infra-Guard: A Comprehensive, Intelligent, and Easy-to-Use AI Red Teaming Platform}},
  year={2025},
  howpublished={GitHub repository},
  url={https://github.com/Tencent/AI-Infra-Guard}
}
```
<br>

## 📚 Research & Papers

**Research:**

1. **"RogueHandoff-20: Measuring Susceptibility to Unsafe Agent Trajectories"** — A Docker-based benchmark measuring whether an agent adopts an unsafe trajectory supplied as preceding state, testing susceptibility after exposure to another agent's unsafe strategy. [[code]](./Research/roguehandoff20)

2. **"FORGE-Bench: A Deterministic Benchmark for Loss of Control in Autonomous Agents"** — A deterministic, oracle-based benchmark studying how autonomous agents lose control while pursuing legitimate tasks, evaluating goal pressure, constraint degradation, and unsafe opportunity across 16 domains and 1,800 trajectories. [[arXiv]](https://arxiv.org/abs/2609.11024) [[code]](./Research/forge_bench)

3. **"DeepSeek Harness Indirect Prompt-Injection Assessment"** — Authorized security assessment of DeepSeek Harness against indirect prompt-injection across 14,560 agent runs. [[code]](./Research/deepseek-harness-security-assessment)

4. **"SkillJack: Persistent Skill Backdoors in Self-Evolving Agents"** — Demonstrates how poisoned trajectories can inject persistent backdoors into self-evolving agent skill systems. [[code]](./Research/SkillJack)

**Papers:**

1. **"Securing the AI Agent: A Unified Framework for Multi-Layer Agent Red Teaming"** — A comprehensive framework for securing AI agent systems through multi-layer red teaming across infrastructure, supply chain, runtime interaction, and deployment surfaces. [[arXiv]](https://arxiv.org/pdf/2606.31227) [[pdf]](./Securing_the_AI_Agent.pdf)

2. **"AI-Infra-Guard: An AI Red Teaming Platform"** — Black Hat Europe 2025 Arsenal presentation showcasing A.I.G's capabilities and real-world use cases. [[pdf]](./Arsenal-BHEU2025-AI-Infra-Guard.pdf)

3. **"MCP Unchained: Compromising The AI Agent Ecosystem Via Its Universal Connector"** — Black Hat Europe 2025 talk revealing security risks in the MCP protocol within the AI agent ecosystem. [[pdf]](./BHEU-25-MCP-Unchained-Compromising-The-AI-Agent-Ecosystem-Via-Its-Universal-Connector.pdf)

Thanks to the research teams who have cited A.I.G in their academic work (19 papers):

<details>
<summary>📄 View all 19 cited papers</summary>

1. Chenning Li, Pan Hu, Justin Xu et al. **"ADR: An Agentic Detection System for Enterprise Agentic AI Security."** arXiv preprint arXiv:2605.17380 (2026). [[pdf]](http://arxiv.org/abs/2605.17380v1)

2. Zhaojiacheng Zhou. **"Proteus: A Self-Evolving Red Team for Agent Skill Ecosystems."** arXiv preprint arXiv:2605.11891 (2026). [[pdf]](http://arxiv.org/abs/2605.11891v1)

3. Hengkai Ye, Zhechang Zhang, Jinyuan Jia et al. **"TRUSTDESC: Preventing Tool Poisoning in LLM Applications via Trusted Description Generation."** arXiv preprint arXiv:2604.07536 (2026). [[pdf]](https://arxiv.org/abs/2604.07536)

4. Zenghao Duan, Yuxin Tian, Zhiyi Yin et al. **"SkillAttack: Automated Red Teaming of Agent Skills through Attack Path Refinement."** arXiv preprint arXiv:2604.04989 (2026). [[pdf]](https://arxiv.org/abs/2604.04989)

5. Yiheng Huang, Zhijia Zhao, Bihuan Chen et al. **"From Component Manipulation to System Compromise: Understanding and Detecting Malicious MCP Servers."** arXiv preprint arXiv:2604.01905 (2026). [[pdf]](https://arxiv.org/abs/2604.01905)

6. Yi Ting Shen, Kentaroh Toyoda, Alex Leung. **"MCP-38: A Comprehensive Threat Taxonomy for Model Context Protocol Systems (v1.0)."** arXiv preprint arXiv:2603.18063 (2026). [[pdf]](https://arxiv.org/abs/2603.18063)

7. Yuepeng Hu, Yuqi Jia, Mengyuan Li et al. **"MalTool: Malicious Tool Attacks on LLM Agents."** arXiv preprint arXiv:2602.12194 (2026). [[pdf]](https://arxiv.org/abs/2602.12194)

8. Naen Xu, Jinghuai Zhang, Ping He et al. **"FraudShield: Knowledge Graph Empowered Defense for LLMs against Fraud Attacks."** arXiv preprint arXiv:2601.22485v1 (2026). [[pdf]](http://arxiv.org/abs/2601.22485v1)

9. Ruiqi Li, Zhiqiang Wang, Yunhao Yao et al. **"MCP-ITP: An Automated Framework for Implicit Tool Poisoning in MCP."** arXiv preprint arXiv:2601.07395v1 (2026). [[pdf]](http://arxiv.org/abs/2601.07395v1)

10. Jingxiao Yang, Ping He, Tianyu Du et al. **"HogVul: Black-box Adversarial Code Generation Framework Against LM-based Vulnerability Detectors."** arXiv preprint arXiv:2601.05587v1 (2026). [[pdf]](http://arxiv.org/abs/2601.05587v1)

11. Teofil Bodea, Masanori Misono, Julian Pritzi et al. **"Trusted AI Agents in the Cloud."** arXiv preprint arXiv:2512.05951v1 (2025). [[pdf]](http://arxiv.org/abs/2512.05951v1)

12. Yunyi Zhang, Shibo Cui, Baojun Liu et al. **"Beyond Jailbreak: Unveiling Risks in LLM Applications Arising from Blurred Capability Boundaries."** arXiv preprint arXiv:2511.17874v2 (2025). [[pdf]](http://arxiv.org/abs/2511.17874v2)

13. Bin Wang, Zexin Liu, Hao Yu et al. **"MCPGuard: Automatically Detecting Vulnerabilities in MCP Servers."** arXiv preprint arXiv:2510.23673v1 (2025). [[pdf]](http://arxiv.org/abs/2510.23673v1)

14. Weibo Zhao, Jiahao Liu, Bonan Ruan et al. **"When MCP Servers Attack: Taxonomy, Feasibility, and Mitigation."** arXiv preprint arXiv:2509.24272v1 (2025). [[pdf]](http://arxiv.org/abs/2509.24272v1)

15. Ping He, Changjiang Li, et al. **"Automatic Red Teaming LLM-based Agents with Model Context Protocol Tools."** arXiv preprint arXiv:2509.21011 (2025). [[pdf]](https://arxiv.org/abs/2509.21011)

16. Christian Coleman. **"Behavioral Detection Methods for Automated MCP Server Vulnerability Assessment."** (2025). [[pdf]](https://digitalcommons.odu.edu/cgi/viewcontent.cgi?article=1138&context=covacci-undergraduateresearch)

17. Yixuan Yang, Daoyuan Wu, Yufan Chen. **"MCPSecBench: A Systematic Security Benchmark and Playground for Testing Model Context Protocols."** arXiv preprint arXiv:2508.13220 (2025). [[pdf]](https://arxiv.org/abs/2508.13220)

18. Yongjian Guo, Puzhuo Liu, et al. **"Systematic Analysis of MCP Security."** arXiv preprint arXiv:2508.12538 (2025). [[pdf]](https://arxiv.org/abs/2508.12538)

19. Zexin Wang, Jingjing Li, et al. **"A Survey on AgentOps: Categorization, Challenges, and Future Directions."** arXiv preprint arXiv:2508.02121 (2025). [[pdf]](https://arxiv.org/abs/2508.02121)

</details>

📧 If you have used A.I.G in your research or product, or if we have inadvertently missed your publication, we would love to hear from you! [Contact us here](#-join-the-community).
<br>
<br>

## ⚖️ License & Attribution

This project is open-sourced under the **Apache License 2.0**. We warmly welcome and encourage community contributions, integrations, and derivative works, subject to the following attribution requirements:

1. **Retain notices**: You must retain the `LICENSE` and `NOTICE` files from the original project in any distribution.
2. **Product attribution**: If you integrate AI-Infra-Guard's core code, components, or scanning engine into your open-source project, commercial product, or internal platform, you must clearly state the following in your **product documentation, usage guide, or UI "About" page**:
   > "This project integrates [AI-Infra-Guard](https://github.com/Tencent/AI-Infra-Guard), open-sourced by Tencent Zhuque Lab."
3. **Academic & article citation**: If you use this tool in vulnerability analysis reports, security research articles, or academic papers, please explicitly mention "Tencent Zhuque Lab AI-Infra-Guard" and include a link to the repository.

Repackaging this project as an original product without disclosing its origin is strictly prohibited.

<div>

<a href="https://www.star-history.com/?type=date&repos=Tencent%2FAI-Infra-Guard">
 <picture>
 <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/chart?repos=Tencent/AI-Infra-Guard&type=date&theme=dark&legend=top-left&sealed_token=3aux6V5PKs5SBSuoVgw6MReXo5IzleLoV22UkaLZtWuN6kK4PltQDiq-hrtHpF4smNRGO9dbhrjk9Q4m7FWsPPUQqIsQUUrZkwev7vTDanFVCAHfU1qusQ" />
 <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/chart?repos=Tencent/AI-Infra-Guard&type=date&legend=top-left&sealed_token=3aux6V5PKs5SBSuoVgw6MReXo5IzleLoV22UkaLZtWuN6kK4PltQDiq-hrtHpF4smNRGO9dbhrjk9Q4m7FWsPPUQqIsQUUrZkwev7vTDanFVCAHfU1qusQ" />
 <img alt="Star History Chart" src="https://api.star-history.com/chart?repos=Tencent/AI-Infra-Guard&type=date&legend=top-left&sealed_token=3aux6V5PKs5SBSuoVgw6MReXo5IzleLoV22UkaLZtWuN6kK4PltQDiq-hrtHpF4smNRGO9dbhrjk9Q4m7FWsPPUQqIsQUUrZkwev7vTDanFVCAHfU1qusQ" />
 </picture>
</a>
