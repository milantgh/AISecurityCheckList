# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [v4.6.5] - 2026-10-08

### Added
- **Agent-Scan**: Support custom transforms for SSE responses (PR #600, f59fbe14)
- **MCP-Scan**: Support modern/legacy protocol auto-negotiation and record protocol version (PR #579, 890f21dd)
- **Agent-Scan**: Add OrcaRouter as a first-class provider (PR #619, a7c9b006)
- **Models**: Send extra headers and body fields to the model API (PR #669, ae6fc0d6)
- **DeepTeam**: Resume an interrupted red team run (PR #668, a2ac397e)
- **Data**: Add vulnerability rules [2026-09-25] — 154 CVE rules + 9 fingerprints (PR #679, 1f8ab6f2)
- **Data**: Add vulnerability rules [2026-10-02] — 117 CVE rules + 5 fingerprints (PR #685, 62a939e1)

### Fixed
- **MCP-Scan**: Rate-limit aware retry for LLM calls (PR #651, 874d05b4)
- **Agent-Scan**: Tool.inputSchema renamed to input_schema in mcp 2.0 (PR #614, baa3ec51)
- **Parser**: Keep the pre-release label when normalizing versions (PR #626, 0f5bb1f7)
- **Skill-Scan**: Keep fallback tool-call parameters with their own call (PR #684, 25e58f10)
- **MCP-Scan, Agent-Scan**: Bound stalled streaming responses (PR #678, 63c2bd83)
- **SARIF**: Preserve text remediation in valid results (PR #680, e9e6ed7b)
- **Scanners**: Preserve findings during context compaction (PR #649, a468ee2c)
- **DeepTeam**: RailFence crashes with IndexError when rails <= 1 (e39ec6ef)
- **Skill file**: Fix formatting of description in SKILL.md (PR #580, 8f84377e)

### Changed
- **CI**: Run the Go test suite on push and pull requests (PR #677, ff824825)
- **Test**: Make agent websocket go test build and pass on main (PR #674, 51d63e24)

### Contributors
ichaobuster, BeYoungD, Pawar Priyank, Elwood Zonghao Ying (NY1024), lovejones2914-spec, monem, helo060228, feiyang, Chen Yufeiyang, Jin, Linxiushen (林SO), BevKim, dvd233

## [v4.6.4] - 2026-10-01

### Added
- **Research**: Vendor pikit (https://github.com/NY1024/pikit), a composable prompt-injection research toolkit, under Research/pikit (fe84b853, PR #681)

### Fixed
- **Skill-Scan**: Forward optional reasoning effort to the model API (PR #676, 14beb9b9)

### Changed
- **Docs**: Update Research/pikit README (9f889209)

### Contributors
Elwood Zonghao Ying (NY1024), Patrick Erichsen

## [v4.6.3] - 2026-09-24

### Added
- **DeepTeam**: Write finished test cases to disk during a run (#653)
- **API Checker**: Refill failed fingerprint samples for more reliable model identification

### Fixed
- **API Checker**: Support Claude 5 signatures (PR #667)
- **Prompt-Eval**: Rate-limit aware backoff, circuit breaker and process-group termination
- **Prompt-Eval**: Share rate-limit counter between breaker and model, harden Retry-After parsing
- **Prompt-Eval**: Hoist 'import re' to module top level

### Changed
- **Research (forge_bench)**: Document dataset organization and evaluation-set guidance (PR #662)
- **Docs**: Add FORGE-Bench and RogueHandoff-20 to Research list (PR #661)
- **Docs**: Sync FORGE-Bench and RogueHandoff-20 Research entries across 8 language READMEs
- **Docs**: Add v4.6.2 What's New entry across all 9 README languages (PR #660)
- **Test (agent-scan)**: Pin the detection-skill registration contract (#664)

### Contributors
Elwood Zonghao Ying (NY1024), xiangfanwu, KEXNA, Devam Shah, helo060228, aigsec, aig-doc-bot

## [v4.6.2] - 2026-09-17

### Added
- **Research**: Add FORGE-Bench (forge_bench) — deterministic Loss-of-Control benchmark for autonomous agents
- **Research**: Add clean RogueHandoff-20 benchmark under Research
- **Data**: Add AIG rules [2026-09-11]
- **Skill-Scan**: Bump aig-skill-scan to 0.2.2 (#656)

### Fixed
- **Skill-Scan**: Reduce evidence-free false positives (PR #652)
- **Skill-Scan**: Prevent model tool-call stalls and bound stalled streaming responses
- **Skill-Scan**: Reconcile verdicts with public findings (PR #652)
- **Extract-Vuln**: Strip CDATA wrapper and accept common tag aliases (PR #655)
- **Data**: Flatten cvss map to string format to match upstream schema
- **Data**: Resolve 12 YAML validation failures
- **Data**: Remove redundant n8n.yaml fingerprint (upstream has n8n.io.yaml)

### Changed
- **Research (forge_bench)**: Built-in OpenAI-compatible client, bilingual README, and quickstart (PR #658)
- **Docs**: Document English-only contributor text and canonical input language policy
- **Docs**: Add v4.6.1 What's New entry across all 9 README languages
- **Docs**: Revert CATL logo acknowledgement added to all README languages (PR #654/#659)

### Contributors
Elwood Zonghao Ying (NY1024), xiangfanwu, aigsec, AIG-Bot, boy-hack, pythoncheng, feiyang, aig-doc-bot

## [v4.6.1] - 2026-09-10

### Added
- **API Checker**: Add Gemini, Gemma, and GLM fingerprints
- **API Checker**: Update GLM-5.3-Flash fingerprint baseline
- **API Checker**: Update baseline tests

### Fixed
- **MCP-Scan**: Adapt to MCP Python SDK 2.x API changes (PR #606)
- **MCP-Scan**: Cast read_timeout_seconds to float for SDK 2.x type safety
- **MCP-Scan**: Mark empty scan results as possibly-incomplete (PR #623)
- **MCP-Scan**: Preserve security findings in context compaction prompt
- **MCP-Scan**: Always set scanNote in result_meta and log in English
- **MCP-Scan**: Surface the underlying error when MCP connection fails (PR #534)
- **Skill-Scan**: Stop silently hiding .pyc files and skip-dir payloads
- **Task API**: Add skill_scan task type
- **Parser**: Keep pre-release versions below their release in versionCheck (PR #588)
- **Data**: Correct mislabeled product names for CVE-2026-13236/13237/61428 (PR #642)
- **Docker**: Use Tencent Debian mirror for agent build

### Changed
- **Docs**: Add CONTRIBUTING, CODE_OF_CONDUCT, issue/PR templates
- **Docs**: Update skill-scan README pre_scan capability description
- **Docs**: Update task API comment clarifying attachments priority in skill_scan
- **Docs**: Generalize relay consistency check in API Checker docs

### Contributors
Elwood Ying, xiangfanwu, aig-doc-bot, valleyxht, kexinoh, zhuque, pucedoteth, glatinone, chaucerj, boy-hack, Ray Winkelman, KEXNA

## [v4.6.0] - 2026-08-26

### Added
- **API Checker**: New API security audit module with web proxy integration, unified CLI command, and detection algorithms (PR #511)
- **LLM API Poisoning Detection**: New detection for LLM API poisoning attacks (PR #568)
- **Agent-Scan (aig-agent-redteam)**: v5.0.0 mutation engine refactor, merge workflow-attack into mutation-attack
- **YAML Validation**: Strict validation for required ID and severity fields in vulnerability rules
- **Research**: DeepSeek Harness prompt injection assessment
- **Data**: AIG rules [2026-08-07] and [2026-08-14]

### Fixed
- **MCP**: Migrate clients to SDK 2.0; fix streamable_http_client headers param incompatibility with MCP SDK 1.28+
- **MCP-Scan**: Strip lone surrogates from non-UTF-8 filenames; use timedelta for ClientSession read_timeout_seconds
- **Skill-Scan**: Strip lone surrogates to prevent JSON serialization crash
- **Data**: Remove case-colliding duplicate vulnerability rules; escape credential-like reference labels
- **PromptSecurity**: Add missing httpx dependency; stop double-translating case.reason; translate jailbreak report content
- **Agent**: Extract pure URL from user input for MCP scan server_url
- **Agent-Scan**: Localize step titles like MCP Scan
- **i18n**: Honor selected report language for AI Infra Scan CVE data
- **Parser**: Prevent panic on malformed advisory version rules
- **Docker**: Restore published image compose compatibility; use uv sync for agent-scan Python deps
- **API Checker**: Preserve weighted audit deductions
- **YAML Check**: Validate Info.Name, reject empty severity, restore EOF newline

### Changed
- **Docs**: Add OpenClaw Recommended badge, expand Research & Papers section, update CVE count 1900+ → 2000+, update component table (4 new components, 14 CVE count updates), update model recommendations (GLM 5.3, Kimi K3)
- **Refactor**: Embed API checker in agent Docker image

### Contributors
AIG-Bot, Elwood Ying, Flynn Joe, Louis, Zeding Zhang, aig-doc-bot, aigsec, ajay.kumar, donglige, fei, feiyang, ichaobuster, rootkiller6788, xiangfanwu, zhuque

## [v4.5.1] - 2026-07-30

### Added
- **PromptSecurity**: Add Many-Shot, PAIR, GOAT and ActorAttack multi-turn jailbreak attacks (a4209457)
- **Agent-Scan**: Add 5 new OWASP detection skills (agentic-supply-chain, cascading-failure, human-agent-trust, inter-agent-comm, unexpected-code-execution) (96d91321, 11f48544)
- **Agent-Scan**: Add web-exfiltration-detection skill and case2 test (39cddc07)
- **MCP-Scan**: Add 4 new MCP security detection rules (hardcoded secrets, insecure deserialization) (8db11c70)
- **Data**: Add AIG rules [2026-07-24] (b80c6289)
- **Docs**: Add v4.5.0 What's New entry across all 9 README languages (014103f4)

### Fixed
- Fix(frontend): Prevent checkbox jumping when attack method text is long (1569b30a) — Closes #331
- Fix: Remove duplicate fingerprint open-webui.yaml (7cb4805a)
- Fix: Convert cvss dict to string, remove reference from info block (8fe29351)
- Fix: Unify author to A.I.G bot (bb51fe55)

### Changed
- Docs: Update v4.5.0 What's New with 5-item summary and revise bottom links across all 9 README languages (31218640)
- Docs: Replace broken star-history link with sealed_token embed, remove AIG_Technical_Report.pdf (8b3f3d9d)

## [v4.5.0] - 2026-07-27

### Added
- **Frontend**: Open-source frontend code with open-source environment configuration (5cb33e22, bed369b2)
- **Agent-Scan**: Modularize as standalone CLI with AIG integration support (2a18b88e)
- **Agent-Scan**: Add 4 new detection skills for AI agent security (5f7022fd)
- **Agent-Scan**: Register 4 new detection skills in _DETECTION_SKILLS (9c2c0f8c)
- **MCP-Scan**: Modularize with dual-mode support (CLI + AIG Web) (272c56e6)
- **MCP-Scan**: Add standalone mcp-scan-lite module (d93e69a8)
- **MCP-Scan**: Add 2 MCP security detection rules (#458)
- **MCP-Scan**: Add ATR-derived MCP detection rules for further attack surfaces (#469)
- **Skill-Scan**: Add Agent Skill security auditing support (78ddc07c)
- **Skill-Scan**: Repackage as standalone PyPI package aig-skill-scan (545ed4b3)
- **Skill-Scan**: SARIF 2.1.0 output + single-stage optimization (d32a56f6)
- **Eval**: Add agentic-tool-misuse evaluation dataset (#427)
- **Data**: Add AIG rules [2026-06-29], [2026-07-13], [2026-07-17]
- **Data**: Add CVE rules for Jan, Open WebUI, crewai, lobehub components
- **Data**: Add ai component fingerprints (#459)
- **Data**: Add missing English vuln rules
- **Docs**: Add aig-skill-scan and SkillTrustBench to README
- **Docs**: Add Tiane and Binus University to user acknowledgements

### Changed
- **Frontend**: Add open-source environment configuration and UI improvements
- **MCP-Scan**: Remove redundant aig-mcp-scan-lite module (ff4a6b39)
- **Skill-Scan**: Simplify to single default LLM, rebrand to aig-skill-scan (982d938a)
- **Skill-Scan**: Stage 2 Code Audit output Markdown report instead of XML (04f48f3c)
- **Docs**: Update CVE count to 1700+ and fix component counts in ai-infra-scan docs
- **Docs**: Update component/vuln counts after multiple rules updates
- **Docs**: Sync new "Securing the AI Agent" paper across all README languages
- **Docs**: Update readme and technical_report
- **Docs**: Collapse older What's New entries, keep latest 5 visible
- **Docs**: Fix CVE count 1600+ -> 1900+ in README_DE and README_RU

### Fixed
- **Version**: Bypass GitHub API rate limit via releases/latest redirect (7a08609d)
- **Task Manager**: Classify Skill-Scan and rename MCP label (7be6e7ca)
- **i18n**: Bilingual stage titles for mcp-scan and skill-scan (0823a530, c8969cc2)
- **Data**: Remove duplicate OpenClaw/ directories (EN+CN) (a7d53884)
- **Data**: Remove 4 CVE rules without matching fingerprints (d89e8879)
- **Data**: Resolve YAML parse errors in 4 vuln rule files (a7af7579)
- **Data**: Correct info.name to match fingerprint names (case-sensitive) (f7de1bc1, 9552ebfd)
- **Data**: Fix missing CN translations for multiple CVE rules
- **Docs**: Fix Python version requirement in skill-scan docs (3.12 -> 3.9) (fff4bb99)
- **Docs**: Fix EN README CHANGELOG link text from Chinese to English (e21733d6)

### Chore
- Remove redundant aig-mcp-scan-lite module
- Add yamlcheck to .gitignore
- Bump skill-scan version to 0.2.0

### Contributors
Special thanks to @zhuque, @aigsec, @aigdocs[bot], @boyhack, @Elwood Ying, @DevamShah, @Adam Lin, @fyoungguo, @AIG-Bot

---

## [v4.1.15] - 2026-06-25

### Added
- **API**: Allow omitting model token in mcp_scan and ai_infra_scan, fall back to system default model (f97d707)
- **Data**: Add 6 llama.cpp CVE rules to the llama-cpp pack (8e0d417)
- **MCP**: Add 3 MCP threat detection rules: tool poisoning, credential exfiltration, command injection (de57b10)

### Changed
- **Docs**: Add user feedback survey section to all README files (bf5ed72)
- **Docs**: Fix vuln total count 1300+ -> 1600+ in ai-infra-scan docs (98d4cd9)
- **Docs**: Update llama-cpp vuln count 3->9 and severity Low->Medium-High (e7b97bd)
- **Docs**: Add 9 new single-turn attack operators to AIG-PromptSecurity README (9d6a589)
- **Docs**: Update openclaw vuln count 628 -> 655 in ai-infra-scan docs (aba3988)
- **Docs**: Fix zh v4.1.14 wording: single-turn jailbreak operators -> attack methods (e3cf9a6)
- **Docs**: Remove v4.1.11 What's New entry from all 9 README languages (ec3557d)
- **Docs**: Add v4.1.14 What's New and restore v4.1.11 entry across all 9 README languages (2c662d0)

### Contributors
Special thanks to @zhuque, @aigsec, @aigdocs[bot], @boyhack, @DevamShah, @aig-doc-bot, @Nicky, @Adam Lin

---

## [v4.1.14] - 2026-06-18

### Added
- **Skills**: Add aig-agent-redteam skill for comprehensive Agent security assessment (5eb87a6)
- **Prompt Security**: Add 9 single-turn jailbreak attack methods: PrefillAttack, ICA, PastTense, Overload, Jailbroken, FlipAttack, DeepInception, CodeChameleon, JAM (d48e508)
- **Eval**: Add jailbreak evaluation datasets: AdvBench, CNSafe, SafeBench (e0ce12e)

### Changed
- **Dispatch**: Implement round-robin agent selection for load balancing (Closes #407) (cb0fa37)
- **Docs**: Add AdvBench, CNSafe, SafeBench to dataset credits in prompt-eval docs (52b9737)
- **Docs**: Update DeepTeam repo URL to confident-ai/deepteam (8743b1f)
- **Docs**: Add Nanyang Technological University logo to README (b800978)
- **Docs**: Update What's New to v4.1.13 across all README languages (bb73db9)

### Contributors
Special thanks to @boyhack, @Elwood-Zonghao-Ying, @aigsec, @aigdocs[bot], @aig-doc-bot

---

## [v4.1.13] - 2026-06-11

### Added
- **API**: Add version check endpoint (Closes #376) (5ab5c0f)

### Fixed
- **Scoring**: Replace weighted ratio with absolute deduction model (Closes #403) (cf2170f)

### Changed
- **Docs**: Add China Merchants Bank logo to user appreciation section in all READMEs (c95f052)
- **Docs**: Update What's New to v4.1.12 across all README languages (0a8da63)
- **Docs**: Restore v4.1.11 entry in What's New across all 9 README languages (b341578)

### Contributors
Special thanks to @boyhack, @zhuque, @aigsec, @aigdocs[bot]

---

## [v4.1.12] - 2026-06-08

### Added
- **Fingerprints**: Add 39 new AI web fingerprints and enhance 18 existing ones (7c438fa)

### Fixed
- **Fingerprints**: Fix YAML matcher syntax for CI validation (49e2552)

### Changed
- **Docs**: Update component count to 100+ and CVE count to 1600+ across all languages (58d97ff)
- **Docs**: Add v4.1.11 to What's New across all 9 README languages (39a0cec)

### Contributors
Special thanks to @zhuque, @boyhack, @aig-doc-bot

---

## [v4.1.11] - 2026-06-04

### Changed
- **Docs**: Add Wuhan University and Unicom Digital Tech logos to all READMEs (3af7f63)
- **Docs**: Add v4.1.10 to What's New across all 9 README languages (5e0a6f4)

### Contributors
Special thanks to @aigsec, @jucie-pie, @aig-doc-bot

---

## [v4.1.10] - 2026-05-28

### Added
- **Data**: Add CVE rules and fingerprints for new targets (junoclaw, lollms, sglang) (6054e45)
- **Scan**: Support WebSocket agent providers (2c845e8)

### Fixed
- **Scan**: Resolve uv run failures in Docker and improve dify version detection (23f098a)
- **Chromium**: Add defer Close() to prevent zombie processes (b617bf7)
- **Data**: Correct sglang fingerprint YAML structure (version as top-level key) (653cc9a)

### Changed
- **Docs**: Add v4.1.9 to What's New across all 9 README languages (187442d)

### Contributors
Special thanks to @feiyang666, @boyhack, @zhuque, @jucie-pie, @rocie799, @AIG-Bot, @aig-doc-bot

---

## [v4.1.9] - 2026-05-21

### Added
- **Prompt Security**: Add 20+ single-turn attack operators (invisible-text, case-formatting, script-system, unicode-style, classical-cipher, classic-encoding, SystemOverride, SuperUser, LinguisticConfusion, Roleplay, PromptProbing, PromptInjection, PROMISQROUTE, PermissionEscalation, Multilingual, MathProblem, InputBypass, ICRTJailbreak, GrayBox, GoalRedirection, EquaCode, ContextPoisoning) (fbac88b..14a3d01)
- **Prompt Security**: Add 6 multi-turn attack operators (TreeJailbreaking, SequentialJailbreak, LinearJailbreaking, CrescendoJailbreaking, BestofN, BadLikertJudge) (f4e7cd8..6116a8a)
- **Prompt Security**: Register and document newly added attack operators (03d67de, ce3869c)
- **Scan**: Add indirect prompt injection defense to scanning agent prompts (bce80c9)

### Changed
- **Docs**: Reorder academic citation papers by publication date descending (0ae8625)
- **Docs**: Normalize quotes in DE/RU paper citations to standard format (b9b4d2b)
- **Docs**: Simplify overly formal acknowledgement wording across all languages (5926ade)
- **Docs**: Add Changan Auto and HUST logos to user appreciation section (968710f)
- **Docs**: Sync HUST and Nankai University logo heights (45px) across all READMEs (7ef9cd4, c59eb29)
- **Docs**: Add 1 new related paper to README (b93e1e0)

### Contributors
Special thanks to @y3oZ, @Truman, @zhuque, @boyhack, @aigsec, @aig-doc-bot, @jucie-pie

---

## [v4.1.8] - 2026-05-14

### Fixed
- **Tools**: Make tool name lookup case-insensitive (2e76c7d)
- **Vuln Rules**: Remove 143 duplicate GHSA files that have corresponding CVE references (bf06029)
- **Vuln Rules**: Remove invalid fingerprints (chatgpt-mcp-server/pptagent), fix GHSA-9p3r YAML format (8a19ff8)
- **Vuln Rules**: Restore GHSA files added upstream after base commit (6cdecfd)

### Changed
- **Docs**: Add invitation code application link to all README files (08c356a)
- **Docs**: Add 1 new related paper to README + fix ZH PDF links (2cbc750)
- **Docs**: Add team introduction, core members, and papers section across all READMEs (3ef3cb8)
- **Docs**: Update component count 58→64 and vuln stats 1200+→1300+ across all 9 README languages (0a3b50b)

### Contributors
Special thanks to @feiyang666, @zhuque, @boyhack, @aigsec, @aig-doc-bot, @jucie-pie, @AIG-Bot

---

## [v4.1.7] - 2026-04-30

### Changed
- **Docs**: Update README What's New section with v4.1.6 highlights, update component count (57→58) and vulnerability stats across all 9 README languages (75946d1)
- **Users**: Update user list (7c2a7f1)

### Contributors
Special thanks to @jucie-pie, @aigsec, @aig-doc-bot

---

## [v4.1.6] - 2026-04-23

### Added
- **Docker**: Add git to runtime dependencies in Dockerfile (69f7430)
- **Vuln Rules**: Add AIG vulnerability rules [2026-04-23] (#350)
- **Vuln Rules**: Detect exposed AI agent config files (claude_desktop_config.json, mcp.json, etc.) (#340)
- **Vuln Rules**: Add Trae IDE and CodeBuddy MCP config paths, extend .env key patterns
- **Data Sync**: Replace zip download with git clone, remove github_token dependency (#327)
- **Manual Updates**: Support manual updates to the latest jailbreak datasets, fingerprints, and vulnerability databases
- **Update API**: Merge update-status into update-data endpoint

### Fixed
- **Vuln Rules**: Revert .env matcher to API key pattern matching
- **Vuln Rules**: Remove mcpServers field dependency, match on file format only
- **Vuln Rules**: Replace substring match with regex to reduce false positives
- **Update API**: Return status=1 when last sync failed
- **Update API**: Unify response format to {status, message, data}
- **Update API**: Remove request params, always sync main branch
- **Data Sync**: Harden update_api against CodeQL path-injection and command-injection alerts
- **Vuln Rules**: Update GHSA-8fmp-37rc-p5g7.yaml and OpenClaw versioning rule

### Contributors
Special thanks to @feiyang666, @zhuque, @boyhack, @aigsec, @aig-doc-bot

---

## [v4.1.4] - 2026-04-17

### Security
- **TLS**: Support HTTPS connections with self-signed/private CA certificates for model endpoints; add InsecureSkipVerify option (#306, closes #302)

### Added
- **MCP Scan**: Add multi-turn red team attack module with TAP and Crescendo strategies (#299)
- **System API**: Add data auto-sync API (`POST /api/v1/system/update-data`, `GET /api/v1/system/update-status`) for syncing `data/` directory (#301)
- **Agent Scan API**: Support inline `agent_config` in agent scan API, make verify optional on save (#322)
- **CLI**: Support `--agent-config-file` for inline YAML agent scan config (aig-scanner v1.0.3)
- **Security Policy**: Add SECURITY.md with trust model and vulnerability disclosure policy

### Fixed
- **Vulnerability Rules**: Fill empty rule fields and add new CVE rules
- **API**: Fix mcp_scan content field and add agent_scan API documentation
- **Docs**: Fix HTML block bold rendering in multilingual READMEs
- **Architecture**: Fix runtime path resolution for local deployments

### Changed
- **Codebase**: Convert all Chinese comments and messages to English in api.go and knowledge2_api.go
- **Docs**: Expand Related Papers to 17 entries with 5 new 2026 papers; sync across all multilingual READMEs
- **Docs**: Add architecture evolution document covering v0.1/v2.6/v3.6.0 (#294)
- **Vulnerability Stats**: Update component vulnerability counts, add crewai/kubeai/lobehub entries (#291)

### Contributors
Special thanks to @boyhack, @zhuque, @ac0d3r, @feiyang666, @rocie799, @aig-doc-bot

---

## [v4.1.3] - 2026-04-09

### Fixed
- **Fingerprint**: Add version extractor to OpenClaw fingerprint for accurate version detection (#286)
- **MCP Scan**: Harden agent loop and path validation, clean up config (#282)

### Changed
- **Vulnerability Rules**: Remove duplicate GHSA files already covered by CVE entries (OpenClaw dedup)

### Documentation
- Add quick usage guide with concrete scan target examples (issue #281)
- Sync env.example context window vars, update install and test commands for MCP scan
- Fix README_JA quick guide missing sections and correct OpenClaw vuln count (474→451)
- Restructure and sync What's New sections across EN/ZH/JA READMEs

### Contributors
Special thanks to @boyhack, @zhuque, @zznQ, @feiyang666, @juciepie, @aig-doc-bot

---

## [v4.1.2] - 2026-04-03

### Fixed
- **Task Control**: Added support for stopping running tasks, allowing users to actively terminate scans in progress
- **AI Infra Scan**: Fixed a bug where the "No Model" option could not be selected in AI infrastructure scan task configuration, preventing users from creating model-free scan tasks
- **AI Infra Scan**: Fixed double-dot filename bug in scan file upload that caused certain filenames to be incorrectly rejected
- **AI Infra Scan**: Fixed concurrent goroutine hang in multi-IP scan scenarios, improving scan stability and task completion reliability
- **Agent Scan**: Hardened LLM error handling to prevent scan crashes on unexpected model responses
- **LLM Input**: Fixed inappropriate input text passed to LLM in certain scan scenarios

### Added
- **Vulnerability Rules [2026-03-26]**: Added 15 new CVE rules covering n8n (×11), OpenClaw (×3), llama.cpp (×1)
- **Vulnerability Rules [2026-03-27]**: Added 29 new CVE rules covering BentoML (×1), Langflow (×2), OpenClaw (×26); added BentoML fingerprint
- **Vulnerability Rules [2026-03-30]**: Added 15 new CVE rules covering Langflow (×1), LibreChat (×4), LoLLMs (×1), MLflow (×1), OpenClaw (×8); added Wallos fingerprint
- **Coverage**: AI component vulnerability coverage expanded to **52 components / 1000+ CVEs**

### Changed
- **Fingerprint Accuracy**: Aligned fingerprint `info.name` with vulnerability rule names for consistent detection matching
- **Documentation**: Updated AI infra scan component and CVE statistics in README

### Contributors
Special thanks to @feiyang666, @Yang1k, @aigsec

---

## [v4.1.1] - 2026-03-25

### Added
- **New Vulnerability Rules**: Added AIG rules batch [2026-03-25], expanding AI component vulnerability detection coverage
- **Fingerprint Enhancement**: Added correct new-api fingerprint matcher syntax (FOFA 100%)

### Fixed
- **Security**: Mask token fields in GetTaskDetail response to prevent credential leakage (#226)
- **MCP Scan**: Fix missing imports and mcp_tool alias in mcp_tool module
- **Documentation**: Fix incorrect license name in README.md; fix MIT license reference in README_ZH Features section

### Changed
- **CI**: Optimize yaml-lint workflow with Go cache and failure artifact upload
- **Docs**: Update README What's New section to reflect v4.1 features accurately

### Contributors
Special thanks to @feiyang666, @zhuque, @aigsec

---

## [v4.1] - 2026-03-23

### Added
- **New Scan Port**: Added port 18789 to the default AI infrastructure scan port list for broader AI component coverage
- **New Vulnerability Rules**: Added AIG Rules (2026-03-20 batch), continuously expanding the AI component vulnerability detection rule library
- **OpenClaw Vulnerability Database**: Added 281 new CVE/GHSA entries for OpenClaw components, covering a wide range of AI infrastructure security advisories
- **YAML CI/CD Validation**: Introduced automated YAML format validation pipeline via CSCD; triggered on PR and Push events to ensure rule compliance before merge
- **Task API Enhancement**: Improved taskapi lifecycle management and Agent Scan support
- **edgeone-clawscan Skill**: Added EdgeOne-based ClawScan security scanning Skill powered by Tencent Zhuque Lab AI-Infra-Guard

### Changed
- **License Migration**: Migrated from MIT to Apache 2.0; added NOTICE file with attribution requirements
- **License Headers**: Added Apache 2.0 license headers to all `.go` and `.py` source files

### Fixed
- **CodeQL Hardening**: Completed CodeQL path-injection remediation (Round 2), closing all related security alerts
- **Score Normalization**: Fixed severity case inconsistency in `CalcSecScore` and added support for Chinese severity levels (#178)
- **Agent Config Path Validation**: Fixed path injection risk in `readAgentConfigContent`, added input validation and boundary checks
- **Documentation Fixes**: Fixed ClawScan URL formatting, broken links, and other documentation errors

### Docs
- Added AI coding assistant guideline files: CLAUDE.md, CODEBUDDY.md, AGENTS.md
- Updated README and README_ZH.md with v4.0 feature descriptions and capability overview
- Moved license section to bottom of README_ZH.md; fixed license filename reference to `LICENSE`

### Changed (additional)
- Enforced open-source standards across README, CHANGELOG, NOTICE, and YAML CI configuration

### Contributors
Special thanks to @zhuque, @boyhack, @Nicky, @rocie799, @aigsec

---

## [v4.0] - 2026-03-10

### Added
- **Agent-Scan Framework**: Introduced a brand-new Agent-Scan scanning engine — a complete AI-powered autonomous agent security scanning framework
  - Multi-agent architecture with specialized sub-agents: main agent, SSRF agent, config-scanner agent, vulnerability detector agent, agent security reviewer, and data leakage detection agent
  - Full tool ecosystem including bash, file read/write, edit, grep, glob, ls, batch, thinking, todo, task, skill, MCP tool, dialogue, and finish actions
  - Agent adapter system with support for multiple providers (Dify, Coze, etc.) with streaming response and connectivity testing
  - Skill-based scanning capabilities: OWASP ASI compliance, authorization bypass detection, indirect injection detection, tool abuse detection, data leakage detection (with static & advanced prompt sets and LLM evaluator)
  - Agent security review report generation with structured vulnerability assessment
  - Scan pipeline with dialogue count tracking, tool usage statistics, and async processing
- **Claw-Scan Enhancement**: Improved ClawScan (AIG-PromptSecurity) evaluation framework
- **Component Fingerprints**: Added 4 new AI component fingerprints for improved detection coverage
  - llama.cpp, HuggingFace TGI, NVIDIA NIM, LocalAI

### Changed
- 🐳 **Docker Optimization**: Updated Dockerfile and deployment scripts
  - Use shallow clone and prefer docker compose v2 in `docker.sh`
  - Handle chmod failures gracefully in `start.sh`
  - Updated Dockerfile for Agent-Scan support
- 📝 **Documentation Updates**: Comprehensive README updates
  - Updated README to include Agent Skills in scans
  - Updated README_ZH.md for clarity and accuracy
  - Updated research papers and news sections
- ⚙️ **Configuration Refactoring**: Removed some provider configurations, restructured field hierarchy
  - Removed `idSuffix` field and updated related logic
  - Improved parsing compatibility for config files
  - Updated config JSON files with icon support

### Contributors
Special thanks to @rocie799, @Truman, @test0Emma, @hobostay, @Yang Luo, @mhh

---

## [v3.6.2] - 2026-02-09

### Added
- 🛡️ **Vulnerability Database Expansion**: Added 78 new CVE entries across 15 AI/ML infrastructure components
  - **anythingllm** (1): CVE-2025-63390
  - **comfyui** (2): CVE-2025-67303, CVE-2026-22777
  - **dask** (1): CVE-2026-23528
  - **dify** (4): CVE-2025-56157, CVE-2025-63386, CVE-2025-63387, CVE-2025-63388
  - **feast** (1): CVE-2025-11157
  - **jupyter-notebook** (1): CVE-2025-53000
  - **langchain** (4): CVE-2024-58340, CVE-2025-67644, CVE-2025-68664, CVE-2025-68665
  - **langflow** (9): CVE-2025-34291, CVE-2025-68477, CVE-2025-68478, CVE-2026-0768, CVE-2026-0769, CVE-2026-0770, CVE-2026-0771, CVE-2026-0772, CVE-2026-21445
  - **lobechat** (1): CVE-2026-23835
  - **mlflow** (3): CVE-2025-10279, CVE-2025-14279, CVE-2026-22607
  - **n8n** (33): CVE-2023-27562, CVE-2023-27563, CVE-2023-27564, CVE-2025-46343, CVE-2025-49592, CVE-2025-49595, CVE-2025-52478, CVE-2025-52554, CVE-2025-55526, CVE-2025-57749, CVE-2025-61914, CVE-2025-61917, CVE-2025-62726, CVE-2025-65964, CVE-2025-68613, CVE-2025-68668, CVE-2025-68697, CVE-2025-68949, CVE-2026-0863, CVE-2026-1470, CVE-2026-21858, CVE-2026-21877, CVE-2026-21893, CVE-2026-21894, CVE-2026-25049, CVE-2026-25051, CVE-2026-25052, CVE-2026-25053, CVE-2026-25054, CVE-2026-25055, CVE-2026-25056, CVE-2026-25115, CVE-2026-25631
  - **ollama** (5): CVE-2025-15063, CVE-2025-15514, CVE-2025-63389, CVE-2025-66959, CVE-2025-66960
  - **open-webui** (1): CVE-2025-63391
  - **simstudioai** (8): CVE-2025-7107, CVE-2025-7114, CVE-2025-9800, CVE-2025-9801, CVE-2025-9805, CVE-2025-10096, CVE-2025-10097, CVE-2025-15099
  - **vllm** (4): CVE-2026-22773, CVE-2026-22778, CVE-2026-22807, CVE-2026-24779

### Changed
- 📝 **CVE Updates**: Updated existing vulnerability entries for improved accuracy
  - clickhouse: CVE-2024-23689
  - gradio: CVE-2024-1728
  - langchain: CVE-2025-65106
  - langflow: CVE-2025-57760
  - mlflow: CVE-2025-11201
  - vllm: CVE-2025-62164

---

## [v3.6.1] - 2026-01-27

### Added
- 🆔 **Component Fingerprints**: Added Clawdbot Gateway fingerprint to improve AI component vulnerability detection coverage.

## [v3.6.0] - 2025-01-17

### Added
- 🔐 **System Administration**: Added SYS_ADMIN capability for Chrome sandbox and database indexes for performance enhancement (@zhuque)
- 📊 **Report Enhancement**: Updated feature and pager, resolved text misalignment in PDF report download (@zonashi)
- 📝 **User Guide**: Updated user guide for new features (@zonashi)
- ⏱️ **Scan Metrics**: Added model & scan duration in AI tool protocol scan report (@zonashi)
- 👥 **User Management**: Refactored User struct and enhanced user management methods (@boyhack)

### Changed
- 📚 **Documentation**: Updated API docs, Swagger docs, and model API (@zhuque)
- 🐳 **Docker Config**: Updated docker-compose.yml and docker-compose.images.yml (@zhuque)
- 🔢 **Versioning**: Updated version to v3.6.0 (@zhuque)
- 🧠 **LLM Result**: Added LLM parameter to MCP meta result (@zhuque)
- 🗄️ **Database**: Fixed LLM model database (@zhuque)
- 🔐 **Auth**: Implemented inner API auth controller (@zhuque)
- 🎯 **Score Correction**: Corrected CalcSecScore method in runner.py to handle Chinese risk levels correctly (@mhh)
- ⚖️ **Risk Type**: Corrected item.RiskType to item.Severity in scoring logic (@mhh)

### Fixed
- 🧪 **Testing**: Removed test info (@zhuque)

### Contributors
Special thanks to @mhh, @aaasven

---

## [v3.6.0-rc1] - 2025-01-07

### Changed
- 🎯 **Audit Prompt Optimization**: Reduced false positives by focusing on network-layer vulnerabilities
  - Added input source risk priority rules, ignoring CLI inputs
  - Only report medium+ severity vulnerabilities
  - Command injection detection excludes CLI parameter scenarios
  - Credential theft detection requires network exfiltration path
- 🔍 **Skill Project Audit**: Improved Skill project security analysis
  - Skill projects don't require MCP risk classification
  - Focus on malicious behavior detection (reverse shell, data exfiltration, backdoor, cryptominer)
  - Ignore code quality and development standard issues
- ✅ **Quality Checklist**: Added network reachability verification to vulnerability review

---

## [v3.5.0] - 2025-12-26

### Added
- 📚 **Research & Documentation**: Added AIG Technical Report, Black Hat Europe 2025 slides, and Black Hat Arsenal presentation (@hermitgreen, @Nicky, @LouisHovaldt)
- 🎓 **Academic Collaborations**: Added academic collaboration section with partner institutions (@zonashi)
- 🔍 **Dynamic Analysis Framework**: Complete dynamic analysis workflow with specialized agents for malicious behavior testing and vulnerability testing (@sc, @MoonBirdLin)
- 🛡️ **Security Detection**: Tool poisoning detection and rug pull detection support (@sc)
- 📊 **Evaluation Datasets**: Added comprehensive test datasets (copyright-violation, misinformation, privacy-leakage, unethical-behavior, violent, non-violent-illegal-activity) (@zonashi)
- 🔧 **MCP Tools Enhancement**: Added mcp_tool for remote MCP server tool invocation (@zhuque)
- 📝 **File Operations**: Added write_file tool for file writing operations (@zhuque)
- 🔌 **Version API**: Added version router endpoint (@zhuque)
- 🎯 **Prompt Manager**: Introduced prompt_manager utility for better prompt template management (@zhuque)
- 🔐 **MCP Header Support**: Added custom MCP header support for authentication and protocol configuration (@zhuque)

### Changed
- ♻️ **MCP Architecture Refactoring**: Complete overhaul of MCP agent architecture for better modularity and performance (@zhuque, @MoonBirdLin)
- 🎨 **Agent Optimization**: Significantly improved agent prompts and reduced tool execution overhead (@zhuque)
- 📦 **Tool System Redesign**: Introduced ToolDispatcher, refactored tool registry, and improved tool schema management (@zhuque)
- 🐳 **Docker Optimization**: Further reduced Docker Agent image size and improved Dockerfile structure (@zhuque, @ac0d3r)
- 📝 **Logging Enhancement**: Optimized logging system and status update mechanisms (@zhuque)
- 🔄 **Prompt Updates**: Comprehensive updates to code audit, project summary, and vulnerability review prompts (@zhuque)
- 📦 **Dependencies**: Updated requirements, pinned deepeval to <3.7.6 for compatibility (@zhuque, @Truman)
- 🎯 **Scoring Algorithm**: Improved calc_mcp_score function for better vulnerability assessment (@zhuque)
- 🌐 **README Updates**: Enhanced README with better structure, GIF demos, and recommended security tools (@zonashi)
- 📡 **Backend API Simplification**: Refactored and simplified MCP-scan backend API, reduced code complexity in websocket/api.go (@zhuque)
- 📖 **API Documentation**: Updated Swagger documentation with latest API endpoints and improvements (@zhuque)
- 🎨 **Frontend UI Optimization**: Enhanced LLM security check experience with prompt input detection support (@zonashi)
- 🔧 **Frontend Settings Consolidation**: Merged auxiliary functions (plugin management, model management) into unified settings panel for cleaner interface (@zonashi)
- 📋 **Version Display**: Added version number and changelog display in frontend for easier issue tracking (@zonashi)
- 🔐 **MCP Header Configuration**: Added MCP scan header configuration in frontend to support MCP service authentication (@zonashi)

### Fixed
- 🐛 **MCP Agent Bugs**: Fixed various MCP agent bugs and improved stability (@boy-hack, @zhuque)
- 🔧 **Execute Actions**: Fixed execute_actions timeout handling and parameter type conversion (@zhuque)
- 🎯 **Transport Type**: Fixed server_transport type issue (@sc)
- 📊 **Output Handling**: Fixed error output when testing without function invocation but with mcp_function invocation (@MoonBirdLin)
- 🛠️ **System Robustness**: Multiple bug fixes for improved system stability (@zhuque, @MoonBirdLin)
- 📝 **LLM Integration**: Fixed llm.py parameter handling and retry logic (@zhuque)
- 🔐 **Frontend Header Bug**: Fixed AI infrastructure scan header configuration not taking effect (@zonashi)

### Contributors
Special thanks to @zhuque, @sc, @MoonBirdLin, @zonashi, @Truman, @ac0d3r, @hermitgreen, @Nicky, @LouisHovaldt, @boy-hack

---

## [v3.5-rc3] - 2025-12-10
- fixed mcp-scan not found directory bug
- update frontend

## [v3.5-preview-2] - 2025-12-05
### Changed
- Improved the onboarding guide for frontend newcomers
- Vulnerability database: Added 100+ AI component CVEs, with support for detecting the latest React2Shell vulnerability (CVE-2025-55182), which affects popular AI frameworks such as Dify, NextChat, and LobeChat.

## [v3.5-preview] - 2025-12-04

### Added
- 🔍 **MCP-Scan Framework**: AI-powered security scanning framework for Model Context Protocol with autonomous agent-based code audit and vulnerability review (@zhuque)
- 🎯 **Advanced Attack Methods**: Added 12+ new encoding/obfuscation attack methods (A1Z26, AffineCipher, AsciiSmuggling, Aurebesh, Caesar, Leetspeak, MirrorText, Ogham, Vaporwave, Zalgo, Stego, StrataSword suite) (@Truman)
- 📸 **Screenshot Capabilities**: Chromium-based headless screenshot functionality for web scanning (@zhuque)
- 🔐 **Model API Security**: Token masking, API key preservation, and public model access controls (@n-WN)
- 📊 **Hash-Based Fingerprinting**: Hash matcher and version range support for component identification (@KEXNA, @Cursor Agent)
- 🌐 **Documentation**: Comprehensive English docs, FAQ, MCP-Scan guides, and research paper references (@zonashi, @zhuque)
- 🐳 **Docker Optimization**: Reduced agent image size from ~2.9GB to ~2.3GB, improved deployment scripts (@n-WN, @zhuque)

### Changed
- ♻️ **Backend Refactoring**: Optimized AI infrastructure scan architecture, reduced agent task code by ~65% (@zhuque)
- 🔄 **MCP Plugin**: Streamlined plugin architecture, removed redundant templates (@zhuque)
- 🚀 **Model Compatibility**: Enhanced parameter compatibility and retry logic across providers (@Truman)
- 🎨 **Code Quality**: Translated comments to English, improved formatting and documentation (@zhuque)

### Fixed
- 🐛 Fixed AI Infra Guard path resolution and Chromium sandbox issues (@zhuque)
- 🔧 Fixed Docker deployment errors (issue #105) and build optimizations (@n-WN, @zhuque)
- ⚙️ Fixed fingerprint parser syntax and version detection logic (@Cursor Agent, @KEXNA)
- 📊 Updated UI badges, screenshots, and license file naming (@zonashi, @Zonazzzz)

### Contributors
Special thanks to @zhuque, @Truman, @n-WN, @KEXNA, @zonashi, @Cursor Agent, @copilot-swe-agent[bot], @boy-hack, @Zonazzzz, @robertzyang, @Coursen

---

## [v3.4.4] - 2025-11-05

### Fixed
1. Fixed issue where prompts could be incorrectly split
2. Added generalized model loading logs
3. Added model loading parameter combination attempts
4. Fixed model invocation parameter compatibility issue
5. Optimized log display
6. Fixed https://github.com/Tencent/AI-Infra-Guard/issues/110

## [v3.4.3] - 2025-10-27
### Added
🔧 **API Documentation Support**: Updated and enhanced API documentation support, providing more complete interface documentation and Swagger specifications.
🤖 **Model Invocation Base Class**: Added base class methods for model invocation, improving code reusability and maintainability.
📊 **Evaluation Dataset Expansion**: Added test datasets related to Cyberattack and CBRN weapons.

### Fixed
🛠️ **CSV Encoding Issue**: Fixed Chinese garbled text issue in CSV files, improving data export experience.

## [v3.4.2] - 2025-09-25
- Optimized frontend
- Added new vulnerability fingerprints:
clickhouse
comfyui
dask
gradio
langchain
langflow
langfuse
LiteLLM
ollama
open-webui
pyload-ng
ragflow
ray
triton-inference-server
vllm


## [v3.4.1] - 2025-09-24
- Added vulnerability fingerprint CVE-2025-23316
- Optimized: triton fingerprint

## [v3.4] - 2025-09-18
### Added
🌐 **Internationalization Support**: Implemented frontend interface internationalization (i18n) support, including multi-language text and English screenshot resources.
🐳 **Docker Enhancement**: Updated one-click deployment script, added Docker pull error information prompt, and supported Apple ARM architecture deployment.
⚡ **Task Concurrency Control**: Added task concurrency limit feature, optimized system resource management.
🔄 **Model Retry Logic**: Updated model invocation retry mechanism, improving service stability.
🤖 **Agent Auto-Recovery**: Implemented automatic restart function after Agent process abnormal exit.
📚 **Multi-Dataset Compatibility**: Enhanced compatibility handling for multiple dataset formats.
🔌 **OpenAPI Interface Update**: Handled the issue of thinking model thinking process being too long.

### Fixed
🛠️ **Frontend Issue Fix**: Fixed frontend interface display issues, including narrow screen adaptation and specific UI anomalies (#74).
🔧 **MCP Issue Fix**: Fixed known bugs in MCP protocol, including model output processing and connection stability.
⚙️ **Parameter Parsing Error**: Fixed exception issues in parameter parsing process.
📊 **Evaluation Exception Fix**: Fixed abnormal behavior in evaluation module.
🔄 **Task Reset Failure**: Fixed the issue of task reset operation failure while running.
🛡️ **Security Risk Fix**: Fixed security risk issues related to IP checking (#78).
🔗 **Circular Import Issue**: Fixed possible circular import errors in code.
📝 **License Update**: Updated project license files.

## [v3.3] - 2025-09-03
- Added one-click Docker deployment script for Linux
- Fixed SSE connection failure issue when disk read/write is slow
- Optimized AI infrastructure scanning probe

## [v3.2] - 2025-08-26

### Added

- 📊 **MCP Scan Report Optimization**: Added more dimensions of detection data display, improving user experience.
- 📱 **Narrow Screen Security Report Adaptation**: Optimized the display of large model security check reports on narrow screens.
- ⚙️ **New Model Concurrency Limit**: Introduced new model concurrency limit feature.

### Fixed

- 🔌 **Fixed MCP SSE Timeout Issue**: Resolved the timeout issue of Server-Sent Events (SSE) in MCP (Model Control Protocol).
- ❓ **Fixed MCP Model Empty Output Exit Issue**: Resolved the issue where the system would exit when MCP model output is empty (#61).
- 📋 **Updated MCP Hardcoded Template**: Updated the hardcoded template for MCP.
- 🛡️ **Fixed AIG Prompt IP Check Risk**: Fixed security risks related to IP checking in AIG prompts.
