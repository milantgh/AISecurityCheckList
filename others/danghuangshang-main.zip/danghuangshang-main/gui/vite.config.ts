import { defineConfig } from "vite"
import react from "@vitejs/plugin-react"
import tailwindcss from "@tailwindcss/vite"

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:18795",
        changeOrigin: true,
      },
      "/ws": {
        target: "ws://localhost:18795",
        ws: true,
      },
    },
  },
})
