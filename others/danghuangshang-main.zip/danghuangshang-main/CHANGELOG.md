# 📜 Changelog

## v3.7.1 (2026-05-22)

### OpenClaw 适配 v2026.5.20

无破坏性变更,本次升级聚焦运行时门槛和新增可选字段。

- **Node.js 最低版本 22.16 → 22.19** — 对齐上游 v2026.5.19 强制要求
  - `install.ps1` — 版本探测改为同时校验 major+minor,Windows 安装器下载从 v22.14.0 升级到 v22.19.0
  - `install-mac.sh` — Node 检测加入 minor 校验(>= 22.19),不达标自动 `brew install node@22` 升级
  - `doctor.sh` — `[1/9]` 检查接受 `>= 22.19`,过低改为 warn 提示
  - `package.json` — `engines.node` 由 `>=22.16.0` 提升到 `>=22.19.0`
- **文档** — `EXTERNAL_HERMES.md`、`hermes.example.yaml`、`CONTRIBUTING.md` 版本占位符同步到 2026.5.20
- **`docs/openclaw-upgrade-guide.md`** — 末尾新增 "升级到 2026.5.20" 一节,列出 v2026.5.8 ~ v2026.5.20 的新可选字段(`agents.list[].experimental.localModelLean`、`voice.realtime.bootstrapContextFiles`、`models.providers.<id>.timeoutSeconds`、`security.audit.suppressions`、Discord `agentComponents.ttlMs`、`tools.alsoAllow`)和 Docker 构建参数改名(`OPENCLAW_DOCKER_APT_PACKAGES` → `OPENCLAW_IMAGE_APT_PACKAGES`,新增 `OPENCLAW_IMAGE_PIP_PACKAGES`)

> **现有用户**:已 work 的 `openclaw.json` 无需改动,只需把 Node 升到 22.19。

---

## v3.7.0 (2026-05-10)

### 新功能 — 双 Agent Runtime 并行

- **新增 Hermes Agent 并行 runtime 支持** — 与 OpenClaw 平行,同一套 14 Agent 朝廷设定可两边任选其一或并存
  - `hermes.example.yaml` — Hermes 配置模板,字段对齐 v0.13.0 (v2026.5.7)
  - `EXTERNAL_HERMES.md` — 安装、token 注入、personality 映射、故障排除
  - `install-hermes.sh` — Hermes 一键安装脚本(平行于 install-lite.sh)
  - `docker-compose.hermes.yml` — Hermes 容器编排,与 OpenClaw compose 互不冲突
  - `configs/hermes/env.example` — 多 provider 环境变量模板
  - `configs/hermes/personalities/` — 司礼监 / 内阁 / 都察院 三个核心角色,完整 14 角色可用 `hermes claw migrate` 自动迁移

### OpenClaw 适配 v2026.5.7

- **补齐所有 Discord 账号 `applicationId` 字段** — 67 处遗漏统一补全
  - `openclaw.example.json` (15 处)
  - `configs/tang-sansheng/openclaw.json` (14 处)
  - `configs/feishu/openclaw.json` (19 处)
  - `configs/ming-neige/openclaw.json` (19 处)
  - 上游 OpenClaw 自 v3.5.3 起在 Discord slash 命令注册时强制要求该字段
- **`install-lite.sh` Discord 流程新增 Application ID 输入** — 配套 sed 替换 `YOUR_SILIJIAN_APPLICATION_ID` / `YOUR_DISCORD_SERVER_ID`,内嵌模板补 `applicationId`

### 文档

- `README.md` — 快速开始新增"方式四:用 Hermes Agent runtime"
- `PROJECTS.md` — 相关仓库表新增 Hermes Agent
- `package.json` — keywords 增加 `hermes-agent`、`nous-research`

---

## v3.5.3 (2026-03-19)

### 新功能
- **多制度支持** — 安装时可选择三种制度
  - **唐朝三省制**：中书→门下→尚书，制衡审核（14 Agent）
  - **明朝内阁制**：司礼监 + 内阁，快速迭代（18 Agent）
  - **现代企业制**：CEO/CTO/CFO，国际化（14 Agent）
- **配置模板分离** — `configs/{tang-sansheng,modern-ceo,ming-neige}/`
- **独立审查机制** — 御史台通过 GitHub webhook 触发代码审查

### 配置修复
- **openclaw.example.json** — 所有 18 个 Discord accounts 补充 `applicationId` 字段
- **install.sh** — Discord 配置模板同步补充 `applicationId`
- **install-lite.sh** — Discord 配置模板同步补充 `applicationId`
- **install-mac.sh** — Discord 配置模板同步补充 `applicationId`

### 文档更新
- **docs/regimes.md** — 新增制度选择指南（详细对比 + 工作流程）
- **configs/tang-sansheng/** — 唐朝三省制配置 + SOUL.md
- **configs/modern-ceo/** — 现代企业制配置 + SOUL.md
- **README.md** — 新增 Windows PowerShell 安装命令，版本号更新为 v3.5.3
- **README_EN.md** — 版本号更新为 v3.5.3
- **docs/faq.md** — Windows 支持说明更新（原生 vs WSL2 对比表）
- **docs/windows-wsl.md** — 重构为两种安装方式指南
- **install.ps1** — 修复 WSL2 安装命令说明（`wsl bash -c` 替代直接运行）

### Bug 修复
- 修复 Windows 用户找不到安装指南的问题 (closes #99)
- 修复 Discord 配置缺少 `applicationId` 导致新手配置失败的问题

---

## v3.5.2 (2026-03-13)

---

## v3.5.2 (2026-03-13)

### Bug 修复
- **H-01** `install.sh` — nvm/volta/fnm 环境下不再使用 sudo 安装全局 npm 包，避免系统 npm 与用户 npm 路径冲突
- **H-05** `gui/server/index.js` — `/api/health` 中 wss/sseClients/metricsBuffer 引用改为 optional chaining，消除死代码风险
- **H-06** `openclaw.example.json` — `$HOME/clawd` 替换为 `/home/YOUR_USERNAME/clawd` 占位符，JSON 不再依赖 shell 变量展开
- **H-07** `install.sh` — heredoc 中 `$HOME` 增加空值保护（`${HOME:-/root}`）及空格路径警告
- **H-09** `gui/server/index.js` — `countSessionFile` 从同步 readSync 改为异步 readline stream，不再阻塞 Node 事件循环；新增 50MB 文件大小上限跳过

---

## v3.5.1 (2026-03-12)

### 优化
- **README 重构** — 精简为 ~400 行引导页，详细教程拆分到 `docs/` 目录
- 修复飞书权限数量描述（8→9 个）
- 飞书排查权限表补全 `contact:user.employee_id:readonly`
- 修复 Sandbox 锚点链接
- 插入 mascot 图片
- OpenClaw Hub 链接统一为 OpenClaw Skill 生态
- `clawdhub install` 命令更新为 `openclaw skill install`
- 基础篇/进阶篇 txt 转 markdown 格式（`docs/tutorial-basics.md`、`docs/tutorial-advanced.md`）
- 新增 `docs/` 文档索引和多个拆分文档

---

## v3.5 (2026-03-12)

### 新功能
- **预装 7 个 Skill** — weather / github / notion / hacker-news / browser-use / quadrants / openviking
- **飞书配置全面优化** — 所有示例统一 dmPolicy/groupPolicy/name，权限表补全到 8 项
- **GUI 品牌可配置** — 通过 `VITE_BRAND_NAME` 环境变量自定义品牌名
- **install.sh 安装后自动运行 doctor.sh** 健康检查
- **新增 CONTRIBUTING.md** 贡献指南和 skills/README.md 索引

### Bug 修复
- README 飞书配置示例缺 groupPolicy、结构过时（appId 不在 accounts 里）
- README/README_EN 排查指南权限表从 3 个补全到 8 个
- README 架构图司礼监标注 (main) → (silijian)
- Court.tsx core agent filter 未包含 silijian
- openclaw.example.json 缺少翰林院的 Discord account 和 binding
- Dockerfile `COPY skills/` 路径硬编码
- docker-compose.yml 移除废弃的 `version: '3.8'`
- 基础篇.txt 云服务商占位符替换为 Oracle Cloud 实际链接

### 优化
- doctor.sh 新增 dmPolicy 和顶层 groupPolicy 检查项
- install.sh 飞书安装指引补权限步骤和文档链接
- README_EN 同步预装 Skill 章节和 60+ Skill 措辞

---

## v3.4 (2026-03-11)

### 新功能
- **飞书配置指南** — 完整的飞书接入文档（500+ 行）
- **doctor.sh 飞书诊断** — 自动检测飞书 appId/appSecret/权限/事件订阅
- **GUI 多框架支持** — 自动检测 OpenClaw CLI 和配置目录
- **Docker 部署** — Dockerfile + docker-compose + entrypoint 初始化

### Bug 修复
- GUI 部门映射修正（libu=礼部, libu2=吏部）
- GUI 兼容 `.openclaw` 和 `.openclaw` 配置目录
- GUI 支持 silijian 和 main 两种 agent id
- Dockerfile/docker-compose 路径参数化

---

## v3.0 (2026-03-10)

### 新功能
- **一键安装脚本三合一** — install.sh (Linux) / install-lite.sh / install-mac.sh
- **多部署模式** — Discord 多Bot / 飞书多Bot / 纯 WebUI
- **Web GUI** — React + TypeScript Dashboard（朝堂、会话、Token、Cron 等）
- **OpenViking Skill** — 向量知识库集成
- **Quadrants Skill** — 四象限任务管理

---

## v2.0 (2026-02-22)

### 首次发布
- 三省六部制 × OpenClaw 多 Agent 架构
- 10 Agent 模板（司礼监 + 内阁 + 都察院 + 六部 + 翰林院）
- 内置审批流程（代码→都察院审查，重大决策→内阁审议）
- Discord 多 Bot 模式
- 小红书系列教程配套文字稿
